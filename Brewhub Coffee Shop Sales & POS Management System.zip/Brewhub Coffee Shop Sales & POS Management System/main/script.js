// Always send API requests to the Flask backend, even if the frontend was opened
// through VS Code Live Server on port 5500. Flask runs locally on port 5000.
const API_BASE = `${window.location.protocol}//${window.location.hostname}:5000/api`;
const state = { user: null, products: [], orders: [], cart: new Map(), page: "dashboard" };
const $ = (id) => document.getElementById(id);
const money = (value) => new Intl.NumberFormat("en-PH", { style: "currency", currency: "PHP" }).format(Number(value || 0));
const escapeHtml = (value) => String(value ?? "").replace(/[&<>"']/g, (ch) => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[ch]));
let toastTimer;

function toast(message, isError = false) {
  const el = $("toast"); el.textContent = message; el.className = `toast show${isError ? " error" : ""}`;
  clearTimeout(toastTimer); toastTimer = setTimeout(() => { el.className = "toast"; }, 3200);
}
async function api(path, options = {}) {
  const response = await fetch(`${API_BASE}${path}`, {
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
    credentials: "include",
    ...options
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || `Request failed (${response.status})`);
  return data;
}
async function submitRegistration(nameId, usernameId, passwordId, roleId, extra = {}) {
  return api("/register", { method: "POST", body: JSON.stringify({
    full_name: $(nameId).value.trim(), username: $(usernameId).value.trim(),
    password: $(passwordId).value, role: roleId ? $(roleId).value : "Customer", ...extra
  }) });
}
function setSignedIn(user) {
  state.user = user;
  const role = String(user.role || "").toLowerCase();
  const isCustomer = role === "customer";
  document.querySelectorAll(".admin-staff-only").forEach(el => el.classList.toggle("role-visible", !isCustomer));
  document.querySelectorAll(".customer-staff-only").forEach(el => el.classList.toggle("role-visible", true));
  document.querySelectorAll(".admin-only").forEach(el => el.classList.toggle("role-visible", role === "admin"));
  $("pos-nav-label").textContent = isCustomer ? "Menu & Order" : "Point of Sale";
  $("customer-contact")?.classList.toggle("hidden", !isCustomer);
  $("customer-top-actions")?.classList.toggle("hidden", !isCustomer);
  $("staff-top-actions")?.classList.toggle("hidden", isCustomer);
  $("staff-top-actions").style.display = isCustomer ? "none" : "";
  $("customer-hero")?.classList.toggle("hidden", !isCustomer);
  $("customer-footer")?.classList.toggle("hidden", !isCustomer);
  $("staff-top-actions")?.classList.toggle("hidden", isCustomer);
  $("staff-top-actions").style.display = isCustomer ? "none" : "";
  $("customer-header-name").textContent = user.full_name || "Customer";
  document.getElementById("app-view")?.classList.toggle("customer-mode", isCustomer);
  document.getElementById("contact-modal")?.classList.add("hidden");
  $("customer-name-wrap")?.classList.remove("hidden");
  $("customer-name").value = isCustomer ? (user.full_name || "Customer") : "Walk-in Customer";
  $("customer-name").readOnly = isCustomer;
  $("login-view")?.classList.add("hidden"); $("app-view")?.classList.remove("hidden");
  document.querySelectorAll(".admin-only").forEach(el => el.classList.toggle("role-visible", user.role.toLowerCase() === "admin"));
  $("user-name").textContent = user.full_name; $("user-role").textContent = user.role;
  $("today-date").textContent = new Date().toLocaleDateString("en-PH", { weekday: "short", month: "short", day: "numeric", year: "numeric" });
  showPage(isCustomer ? "home" : "dashboard"); if (!isCustomer) loadDashboard();
}
function signOut() {
  state.user = null; state.cart.clear(); document.querySelectorAll(".admin-only").forEach(el => el.classList.remove("role-visible")); $("app-view")?.classList.add("hidden"); $("login-view")?.classList.remove("hidden"); $("password").value = "";
}
function showPage(page) {
  const role = String(state.user?.role || "").toLowerCase();
  if (role === "customer" && !["home", "pos", "orders"].includes(page)) page = "home";
  if (role === "staff" && ["accounts", "customers"].includes(page)) page = "dashboard";
  state.page = page;
  document.querySelectorAll(".page").forEach((node) => node.classList.add("hidden"));
  $(`page-${page}`)?.classList.remove("hidden");
  document.querySelectorAll(".nav-link").forEach((node) => node.classList.toggle("active", node.dataset.page === page));
  $("page-title").textContent = ({home:"Home",dashboard:"Dashboard",pos:"Menu",products:"Products",inventory:"Inventory",orders:"Orders",reports:"Sales Reports",accounts:"Admin Accounts",customers:"Customers"})[page] || page;
  if (page === "dashboard" && role !== "customer") loadDashboard();
  if (page === "home") { /* customer landing page */ }
  if (page === "pos") loadProducts();
  if (page === "products") loadProducts();
  if (page === "inventory") loadInventory();
  if (page === "orders") loadOrders();
  if (page === "reports" && role !== "customer") initReportDates();
  if ((page === "accounts" || page === "customers") && state.user?.role?.toLowerCase() !== "admin") { toast("Admin access is required.", true); showPage("dashboard"); return; }
  if (page === "accounts") loadAccounts();
  if (page === "customers") loadCustomers();
}
async function loadDashboard() {
  try {
    const data = await api("/dashboard");
    $("stat-sales").textContent = money(data.sales); $("stat-orders").textContent = data.orders;
    $("stat-low").textContent = data.low_stock; $("stat-products").textContent = data.products;
    const orders = await api("/orders");
    state.orders = orders;
    $("recent-orders").innerHTML = orders.slice(0, 5).map((o) => `<tr><td>#${o.id}</td><td>${escapeHtml(o.customer_name)}</td><td>${escapeHtml(o.created_at)}</td><td>${money(o.total)}</td><td>${statusBadge(o.status)}</td></tr>`).join("") || `<tr><td colspan="5" class="empty">No orders yet.</td></tr>`;
  } catch (e) { toast(e.message, true); }
}
function statusBadge(status) { return `<span class="status ${String(status).toLowerCase()}">${escapeHtml(status)}</span>`; }
async function loadProducts() {
  try {
    state.products = await api("/products");
    renderProducts(); renderMenu(); renderCart();
  } catch (e) { toast(e.message, true); }
}
function imageName(name) {
  const key = String(name).toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_|_$/g, "");
  return `../product_images/${key}.png`;
}
function renderMenu() {
  const search = ($("product-search")?.value || "").toLowerCase();
  const items = state.products.filter((p) => `${p.name} ${p.category}`.toLowerCase().includes(search));
  $("menu-grid").innerHTML = items.map((p) => `<article class="menu-card"><div class="menu-image"><img src="${imageName(p.name)}" alt="${escapeHtml(p.name)}" onerror="this.outerHTML='<span class=&quot;menu-placeholder&quot;>☕</span>'"></div><div class="menu-card-content"><h4>${escapeHtml(p.name)}</h4><small>${escapeHtml(p.category)} · ${p.stock} in stock</small><div class="menu-price">${money(p.price)}</div><button class="primary" data-add-cart="${p.id}" ${p.stock < 1 ? "disabled" : ""}>${p.stock < 1 ? "Out of stock" : "＋ Add to order"}</button></div></article>`).join("") || `<p class="empty">No matching products.</p>`;
}
function renderProducts() {
  $("products-table").innerHTML = state.products.map((p) => `<tr><td><div class="product-cell"><img class="product-thumb" src="${imageName(p.name)}" alt="${escapeHtml(p.name)}" onerror="this.outerHTML='<span class=&quot;product-thumb product-thumb-fallback&quot;>☕</span>'"><strong>${escapeHtml(p.name)}</strong></div></td><td>${escapeHtml(p.category)}</td><td>${money(p.price)}</td><td><span class="stock-number ${p.stock <= 5 ? "stock-low" : "stock-good"}">${p.stock}</span></td><td><button class="small-btn" data-edit-product="${p.id}">Edit</button> <button class="small-btn danger" data-delete-product="${p.id}">Deactivate</button></td></tr>`).join("") || `<tr><td colspan="5" class="empty">No products found.</td></tr>`;
}
function renderCart() {
  const items = [...state.cart.values()];
  $("cart-items").innerHTML = items.map((item) => `<div class="cart-row"><div><strong>${escapeHtml(item.name)}</strong><small>${money(item.price)} each</small><div class="qty-control"><button data-cart-dec="${item.id}">−</button><span>${item.quantity}</span><button data-cart-inc="${item.id}">+</button><button class="remove" data-cart-remove="${item.id}">Remove</button></div></div><strong>${money(item.price * item.quantity)}</strong></div>`).join("") || `<p class="empty">Your cart is empty. Add an item from the menu.</p>`;
  const total = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  $("cart-total").textContent = money(total); $("checkout-btn").disabled = !items.length;
}
async function loadInventory() {
  try {
    const products = await api("/products"); state.products = products;
    renderInventory();
  } catch (e) { toast(e.message, true); }
}
function renderInventory() {
  const search = ($("inventory-search").value || "").toLowerCase();
  const products = state.products.filter((p) => `${p.name} ${p.category}`.toLowerCase().includes(search));
  $("inventory-table").innerHTML = products.map((p) => `<tr><td><div class="product-cell"><img class="product-thumb" src="${imageName(p.name)}" alt="${escapeHtml(p.name)}" onerror="this.outerHTML='<span class=&quot;product-thumb product-thumb-fallback&quot;>☕</span>'"><strong>${escapeHtml(p.name)}</strong></div></td><td>${escapeHtml(p.category)}</td><td><span class="stock-number ${p.stock <= 5 ? "stock-low" : "stock-good"}">${p.stock}</span></td><td><form class="inline-edit" data-stock-form="${p.id}"><input aria-label="New stock quantity" type="number" min="0" step="1" value="${p.stock}" required><button class="small-btn">Save</button></form></td><td>${p.stock <= 5 ? '<span class="status pending">Low stock</span>' : '<span class="status completed">In stock</span>'}</td></tr>`).join("") || `<tr><td colspan="5" class="empty">No inventory items.</td></tr>`;
}
async function loadOrders() {
  try {
    state.orders = await api("/orders");
    if (String(state.user?.role || "").toLowerCase() === "customer") { $("orders-table").innerHTML = state.orders.map(o => `<tr><td>#${o.id}</td><td>${escapeHtml(o.created_at)}</td><td>${money(o.total)}</td><td>${statusBadge(o.status)}</td></tr>`).join("") || `<tr><td colspan="4" class="empty">You have not placed any orders yet.</td></tr>`; const table = $("orders-table").closest("table"); if(table) table.querySelector("thead").innerHTML="<tr><th>Order</th><th>Date</th><th>Total</th><th>Status</th></tr>"; return; }
    const table = $("orders-table").closest("table"); if(table) table.querySelector("thead").innerHTML="<tr><th>Order</th><th>Customer</th><th>Date</th><th>Total</th><th>Status</th><th>Update</th></tr>";
    $("orders-table").innerHTML = state.orders.map((o) => `<tr><td>#${o.id}</td><td>${escapeHtml(o.customer_name)}</td><td>${escapeHtml(o.created_at)}</td><td>${money(o.total)}</td><td>${statusBadge(o.status)}</td><td>${o.status === "Pending" ? `<button class="small-btn" data-order-status="${o.id}" data-status="Preparing">Start</button> <button class="small-btn danger" data-delete-order="${o.id}">Delete</button>` : o.status === "Preparing" ? `<button class="small-btn" data-order-status="${o.id}" data-status="Completed">Complete</button>` : '<span class="muted">Finished</span>'}</td></tr>`).join("") || `<tr><td colspan="6" class="empty">No orders yet.</td></tr>`;
  } catch (e) { toast(e.message, true); }
}
async function loadCustomers() {
  try { const rows = await api("/customers"); state.customers = rows; renderCustomers(); }
  catch (e) { toast(e.message, true); }
}
function renderCustomers() {
  const search = ($("customer-search")?.value || "").toLowerCase();
  const rows = (state.customers || []).filter(c => `${c.full_name} ${c.username} ${c.email || ""} ${c.phone || ""}`.toLowerCase().includes(search));
  $("customers-table").innerHTML = rows.map(c => `<tr><td><strong>${escapeHtml(c.full_name)}</strong></td><td>${escapeHtml(c.username)}</td><td>${escapeHtml(c.created_at || "—")}</td><td><button class="small-btn danger" data-delete-customer="${c.id}">Delete</button></td></tr>`).join("") || `<tr><td colspan="4" class="empty">No customers found.</td></tr>`;
}
async function loadAccounts() {
  try { const rows = await api("/accounts"); state.accounts = rows;
    $("accounts-table").innerHTML = rows.map(a => `<tr><td><strong>${escapeHtml(a.full_name)}</strong></td><td>${escapeHtml(a.username)}</td><td>${escapeHtml(a.role)}</td><td>${Number(a.id) === Number(state.user?.id) ? '<span class="muted">Current account</span>' : `<button class="small-btn danger" data-delete-account="${a.id}">Delete</button>`}</td></tr>`).join("") || `<tr><td colspan="4" class="empty">No accounts found.</td></tr>`;
  } catch(e) { toast(e.message, true); }
}
function initReportDates() {
  if (!$("report-start").value) $("report-start").value = new Date().toISOString().slice(0,10);
  if (!$("report-end").value) $("report-end").value = new Date().toISOString().slice(0,10);
}
async function generateReport(event) {
  event?.preventDefault();
  try {
    const data = await api(`/reports?start=${encodeURIComponent($("report-start").value)}&end=${encodeURIComponent($("report-end").value)}`);
    $("reports-table").innerHTML = data.rows.map((r) => `<tr><td>${escapeHtml(r.sale_date)}</td><td>${r.order_count}</td><td>${money(r.total_sales)}</td></tr>`).join("") || `<tr><td colspan="3" class="empty">No completed sales in this date range.</td></tr>`;
    $("report-summary").textContent = `Total sales: ${money(data.total)} · Completed orders: ${data.order_count}`;
  } catch (e) { toast(e.message, true); }
}
function resetProductForm() {
  $("product-form").reset(); $("product-id").value = ""; $("product-form-title").textContent = "Add product"; $("product-form-panel")?.classList.add("hidden");
}
document.addEventListener("click", async (event) => {
  const nav = event.target.closest("[data-page]");
  if (nav) return showPage(nav.dataset.page);
  const go = event.target.closest("[data-go]");
  if (go) return showPage(go.dataset.go);
  const add = event.target.closest("[data-add-cart]");
  if (add) {
    const p = state.products.find((x) => x.id === Number(add.dataset.addCart));
    if (!p || p.stock < 1) return toast("This product is out of stock.", true);
    const item = state.cart.get(p.id) || { id:p.id, name:p.name, price:Number(p.price), quantity:0 };
    if (item.quantity + 1 > p.stock) return toast(`Only ${p.stock} unit(s) available.`, true);
    item.quantity++; state.cart.set(p.id,item); renderCart(); return;
  }
  const inc = event.target.closest("[data-cart-inc]");
  if (inc) { const id=Number(inc.dataset.cartInc), item=state.cart.get(id), p=state.products.find(x=>x.id===id); if(item&&p&&item.quantity<p.stock)item.quantity++;else toast("No more stock available.",true); renderCart(); return; }
  const dec = event.target.closest("[data-cart-dec]");
  if (dec) { const id=Number(dec.dataset.cartDec), item=state.cart.get(id); if(item){item.quantity--;if(item.quantity<=0)state.cart.delete(id);} renderCart(); return; }
  const remove = event.target.closest("[data-cart-remove]");
  if (remove) { state.cart.delete(Number(remove.dataset.cartRemove)); renderCart(); return; }
  const edit = event.target.closest("[data-edit-product]");
  if (edit) { const p=state.products.find(x=>x.id===Number(edit.dataset.editProduct)); if(!p)return; $("product-id").value=p.id; $("product-name").value=p.name; $("product-category").value=p.category; $("product-price").value=p.price; $("product-stock").value=p.stock; $("product-form-title").textContent="Edit product"; $("product-form-panel")?.classList.remove("hidden"); $("product-form-panel").scrollIntoView({behavior:"smooth"}); return; }
  const del = event.target.closest("[data-delete-product]");
  if (del && confirm("Deactivate this product? It will no longer appear in the POS menu.")) { try { await api(`/products/${del.dataset.deleteProduct}`,{method:"DELETE"}); toast("Product deactivated."); await loadProducts(); } catch(e){toast(e.message,true);} return; }
  const deleteCustomer = event.target.closest("[data-delete-customer]");
  if (deleteCustomer) {
    if (!confirm("Delete this customer profile and its login account? Any order history will be preserved.")) return;
    try { await api(`/customers/${deleteCustomer.dataset.deleteCustomer}`, {method:"DELETE"}); toast("Customer deleted."); await Promise.all([loadCustomers(), loadAccounts()]); }
    catch(e) { toast(e.message, true); }
    return;
  }
  const deleteAccount = event.target.closest("[data-delete-account]");
  if (deleteAccount) {
    if (!confirm("Delete this account? Historical orders will be preserved.")) return;
    try { await api(`/accounts/${deleteAccount.dataset.deleteAccount}`, {method:"DELETE"}); toast("Account deleted."); await Promise.all([loadAccounts(), loadCustomers()]); }
    catch(e) { toast(e.message, true); }
    return;
  }
  const deleteOrder = event.target.closest("[data-delete-order]");
  if (deleteOrder) {
    const orderId = Number(deleteOrder.dataset.deleteOrder);
    if (!confirm(`Delete pending order #${orderId}? Its reserved stock will be returned to inventory.`)) return;
    try {
      await api(`/orders/${orderId}`, {method:"DELETE"});
      toast(`Order #${orderId} deleted and stock restored.`);
      await Promise.all([loadOrders(), loadProducts(), loadInventory()]);
      await loadDashboard();
    } catch (e) { toast(e.message, true); }
    return;
  }
  const status = event.target.closest("[data-order-status]");
  if (status) { try { await api(`/orders/${status.dataset.orderStatus}/status`,{method:"PATCH",body:JSON.stringify({status:status.dataset.status})}); toast("Order status updated."); await loadOrders(); } catch(e){toast(e.message,true);} }
});
$("login-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  try { const data=await api("/login",{method:"POST",body:JSON.stringify({username:$("username").value.trim(),password:$("password").value})}); setSignedIn(data.user); toast(`Welcome, ${data.user.full_name}.`); }
  catch(e){toast(e.message,true);}
});
$("show-customer-register").addEventListener("click", () => { $("login-form")?.classList.add("hidden"); $("public-customer-register-form")?.classList.remove("hidden"); $("show-customer-register").closest(".public-register-toggle").classList.add("hidden"); });
$("hide-customer-register").addEventListener("click", () => { $("public-customer-register-form")?.classList.add("hidden"); $("login-form")?.classList.remove("hidden"); $("show-customer-register").closest(".public-register-toggle").classList.remove("hidden"); });
$("public-customer-register-form").addEventListener("submit", async event => {
  event.preventDefault();
  try {
    const result = await submitRegistration("public-register-name", "public-register-username", "public-register-password", null);
    const createdUsername = $("public-register-username").value.trim();
    event.target.reset(); event.target.classList.add("hidden"); $("login-form")?.classList.remove("hidden"); $("show-customer-register").closest(".public-register-toggle").classList.remove("hidden");
    $("username").value = createdUsername; toast(result.message || "Customer account created. Please sign in.");
  } catch(e) { toast(e.message, true); }
});
$("staff-register-form").addEventListener("submit", async event => {
  event.preventDefault();
  try {
    const result = await submitRegistration("staff-register-name", "staff-register-username", "staff-register-password", "staff-register-role");
    event.target.reset(); toast(result.message || "Account created successfully.");
  } catch(e) { toast(e.message, true); }
});
$("logout-btn")?.addEventListener("click", signOut);
$("customer-logout-btn")?.addEventListener("click", signOut);
$("product-search").addEventListener("input", renderMenu);
$("inventory-search").addEventListener("input", renderInventory);
$("customer-search")?.addEventListener("input", renderCustomers);
$("refresh-accounts")?.addEventListener("click", loadAccounts);
$("clear-cart").addEventListener("click",()=>{state.cart.clear();renderCart();});
$("checkout-btn").addEventListener("click", async () => {
  const cart=[...state.cart.values()].map(({id,quantity})=>({product_id:id,quantity}));
  try { const data=await api("/orders",{method:"POST",body:JSON.stringify({customer_name:state.user?.role?.toLowerCase()==="customer" ? state.user.full_name : ($("customer-name").value.trim()||"Walk-in Customer"),items:cart,user_id:state.user?.id||null})}); state.cart.clear(); toast(`Order #${data.order_id} placed. Total ${money(data.total)}.`); await loadProducts(); if(state.user?.role?.toLowerCase()==="customer"){showPage("orders");} else {showPage("orders");} }
  catch(e){toast(e.message,true);}
});
$("add-product-btn").addEventListener("click",()=>{resetProductForm();$("product-form-panel")?.classList.remove("hidden");});
$("cancel-product").addEventListener("click",resetProductForm);
$("product-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const id=$("product-id").value;
  const body={name:$("product-name").value.trim(),category:$("product-category").value.trim(),price:Number($("product-price").value),stock:Number($("product-stock").value)};
  try { await api(id?`/products/${id}`:"/products",{method:id?"PUT":"POST",body:JSON.stringify(body)}); toast(id?"Product updated.":"Product added."); resetProductForm(); await loadProducts(); }
  catch(e){toast(e.message,true);}
});
document.addEventListener("submit", async (event) => {
  const form=event.target.closest("[data-stock-form]");
  if (!form) return;
  event.preventDefault();
  const input=form.querySelector("input");
  try { await api(`/inventory/${form.dataset.stockForm}`,{method:"PUT",body:JSON.stringify({quantity:Number(input.value)})}); toast("Stock updated."); await loadInventory(); }
  catch(e){toast(e.message,true);}
});
$("report-form").addEventListener("submit",generateReport);
$("refresh-orders").addEventListener("click",loadOrders);
$("year").textContent = new Date().getFullYear();

// Customer-facing navigation and the clickable question-mark contact badge.
function openContactModal(){ const modal=$("contact-modal"); if(modal){modal.classList.remove("hidden"); $("close-contact-modal")?.focus();} }
function closeContactModal(){ $("contact-modal")?.classList.add("hidden"); }
$("contact-help-btn")?.addEventListener("click", openContactModal);
$("contact-help-btn-mobile")?.addEventListener("click", openContactModal);
$("close-contact-modal")?.addEventListener("click", closeContactModal);
document.querySelectorAll("[data-close-contact]").forEach(el=>el.addEventListener("click",closeContactModal));
document.addEventListener("keydown",event=>{if(event.key==="Escape")closeContactModal();});
document.querySelectorAll("[data-customer-page]").forEach(el=>el.addEventListener("click",()=>showPage(el.dataset.customerPage)));
