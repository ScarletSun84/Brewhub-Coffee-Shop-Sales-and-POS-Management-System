"""Launch BrewHub as a native desktop GUI without a console window."""
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
PYTHON_DIR = PROJECT_ROOT / "Python"
if str(PYTHON_DIR) not in sys.path:
    sys.path.insert(0, str(PYTHON_DIR))

from BrewHub_Coffee_Shop_Sales_POS_Management_System import BrewHubApp

if __name__ == "__main__":
    app = BrewHubApp()
    app.mainloop()
