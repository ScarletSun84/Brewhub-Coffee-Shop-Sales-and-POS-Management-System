import sys
from pathlib import Path
from datetime import datetime, date
import customtkinter as ctk
from tkinter import ttk, messagebox
from PIL import Image, ImageOps

# Load the database layer from the sibling Python folder.
PROJECT_ROOT = Path(__file__).resolve().parent.parent
PYTHON_DIR = PROJECT_ROOT / "Python"
if str(PYTHON_DIR) not in sys.path:
    sys.path.insert(0, str(PYTHON_DIR))
from database import Database, hash_password

# ============================================================
# Brewhub Coffee Shop Sales & POS Management System
# SDF04 - Object-Oriented Programming (Python & Database)
# GUI: CustomTkinter | Database: SQLite
# ============================================================

LOGO_FILE = str(PROJECT_ROOT / "brewhub_logo.png")
PRODUCT_IMAGE_DIR = str(PROJECT_ROOT / "product_images")




class Product:
    """OOP model representing a coffee product."""

    def __init__(self, product_id, name, category, price, stock):
        self.id = product_id
        self.name = name
        self.category = category
        self.price = float(price)
        self.stock = int(stock)


class OrderItem:
    """Represents one product and quantity inside an order."""

    def __init__(self, product, quantity):
        self.product = product
        self.quantity = quantity

    @property
    def subtotal(self):
        return self.product.price * self.quantity


class Order:
    """Order business object using encapsulation."""

    def __init__(self, customer_name):
        self.customer_name = customer_name
        self.items = []

    def add_item(self, product, quantity):
        self.items.append(OrderItem(product, quantity))

    @property
    def total(self):
        return sum(item.subtotal for item in self.items)


class OrderManager:
    """Coordinates order creation and validation."""

    def __init__(self, db):
        self.db = db

    def save(self, order, user_id):
        if not order.items:
            raise ValueError("Please add at least one product.")
        cart = {}
        for item in order.items:
            cart[item.product.id] = {
                "name": item.product.name,
                "price": item.product.price,
                "quantity": item.quantity,
            }
        return self.db.create_order(order.customer_name, cart, user_id)


class ReportGenerator:
    """Generates sales report data."""

    def __init__(self, db):
        self.db = db

    def daily(self):
        today = date.today().isoformat()
        return self.db.sales_report(today, today)

    def period(self, start_date, end_date):
        return self.db.sales_report(start_date, end_date)


class BrewHubApp(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("Brewhub Coffee Shop Sales & POS Management System")
        self.geometry("1200x760")
        self.minsize(1000, 650)

        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("blue")

        self.db = Database()
        self.order_manager = OrderManager(self.db)
        self.report_generator = ReportGenerator(self.db)

        self.current_user = None
        self.cart = {}
        self.selected_product_id = None

        self.protocol("WM_DELETE_WINDOW", self.on_close)
        if self.db.user_count() == 0:
            self.show_initial_setup()
        else:
            self.show_login()

    # -------------------- General UI --------------------

    def clear(self):
        for widget in self.winfo_children():
            widget.destroy()

    def title_label(self, parent, text):
        return ctk.CTkLabel(
            parent, text=text, font=ctk.CTkFont(size=28, weight="bold")
        )

    def button(self, parent, text, command, width=150):
        return ctk.CTkButton(parent, text=text, command=command, width=width)

    # -------------------- Initial Account Setup --------------------

    def show_initial_setup(self):
        self.clear()
        frame = ctk.CTkFrame(self, corner_radius=20)
        frame.place(relx=0.5, rely=0.5, anchor="center")
        frame.configure(width=480, height=600)

        logo_path = Path(LOGO_FILE)
        try:
            if logo_path.exists():
                logo_image = Image.open(logo_path).convert("RGBA")
                logo_image.thumbnail((170, 170), Image.LANCZOS)
                self.setup_logo_image = ctk.CTkImage(
                    light_image=logo_image,
                    dark_image=logo_image,
                    size=(170, 170),
                )
                ctk.CTkLabel(frame, image=self.setup_logo_image, text="").pack(pady=(20, 5))
        except Exception:
            ctk.CTkLabel(frame, text="☕", font=ctk.CTkFont(size=55)).pack(pady=(25, 0))

        ctk.CTkLabel(
            frame,
            text="Initial Administrator Setup",
            font=ctk.CTkFont(size=25, weight="bold"),
        ).pack(pady=(5, 5))

        ctk.CTkLabel(
            frame,
            text="No demo account is included. Create your first administrator account.",
            text_color="gray",
            wraplength=390,
            justify="center",
        ).pack(pady=(0, 20))

        name = ctk.CTkEntry(frame, width=340, placeholder_text="Full name")
        username = ctk.CTkEntry(frame, width=340, placeholder_text="Username")
        password = ctk.CTkEntry(frame, width=340, placeholder_text="Password", show="*")
        confirm = ctk.CTkEntry(frame, width=340, placeholder_text="Confirm password", show="*")

        for widget in (name, username, password, confirm):
            widget.pack(pady=8)

        def create_first_admin():
            full_name = name.get().strip()
            user = username.get().strip()
            pwd = password.get()
            confirm_pwd = confirm.get()

            if not full_name or not user or len(pwd) < 6:
                messagebox.showerror(
                    "Invalid Input",
                    "Enter a full name, username, and password of at least 6 characters.",
                )
                return
            if pwd != confirm_pwd:
                messagebox.showerror("Password", "Passwords do not match.")
                return

            try:
                self.db.create_user(full_name, user, pwd, "Admin")
                messagebox.showinfo(
                    "Setup Complete",
                    "Administrator account created successfully. You can now log in.",
                )
                self.show_login()
            except sqlite3.IntegrityError:
                messagebox.showerror("Username Exists", "That username already exists.")

        self.button(frame, "Create Administrator", create_first_admin, 340).pack(pady=20)

    # -------------------- Login --------------------

    def show_login(self):
        self.clear()
        frame = ctk.CTkFrame(self, corner_radius=20)
        frame.place(relx=0.5, rely=0.5, anchor="center")
        frame.configure(width=430, height=500)

        # BrewHub logo. Keep brewhub_logo.png in the same folder as this Python file.
        logo_loaded = False
        try:
            logo_path = Path(LOGO_FILE)
            if logo_path.exists():
                logo_image = Image.open(logo_path).convert("RGBA")
                # CustomTkinter image object for proper high-DPI/scaling support.
                self.logo_image = ctk.CTkImage(
                    light_image=logo_image,
                    dark_image=logo_image,
                    size=(180, 180),
                )
                ctk.CTkLabel(frame, image=self.logo_image, text="").pack(pady=(20, 5))
                logo_loaded = True
        except Exception:
            logo_loaded = False

        if not logo_loaded:
            ctk.CTkLabel(
                frame, text="☕", font=ctk.CTkFont(size=60)
            ).pack(pady=(30, 0))

        ctk.CTkLabel(
            frame,
            text="Brewhub",
            font=ctk.CTkFont(size=34, weight="bold")
        ).pack(pady=(0, 3))
        ctk.CTkLabel(
            frame,
            text="Coffee Shop Sales & POS\nManagement System",
            font=ctk.CTkFont(size=14, weight="bold"),
            justify="center",
        ).pack(pady=(0, 20))

        self.login_username = ctk.CTkEntry(
            frame, width=320, placeholder_text="Username"
        )
        self.login_username.pack(pady=10)

        self.login_password = ctk.CTkEntry(
            frame, width=320, placeholder_text="Password", show="*"
        )
        self.login_password.pack(pady=10)
        self.login_password.bind("<Return>", lambda _: self.login())

        self.button(frame, "Login", self.login, 320).pack(pady=(15, 8))
        ctk.CTkButton(
            frame, text="Create Staff Account", width=320,
            fg_color="transparent", border_width=1,
            command=self.show_create_account
        ).pack(pady=(0, 6))
        ctk.CTkButton(
            frame, text="Create Customer Account", width=320,
            fg_color="transparent", border_width=1,
            command=self.show_create_customer_account
        ).pack(pady=(0, 18))

    def show_create_account(self):
        self.clear()
        frame = ctk.CTkFrame(self, corner_radius=20)
        frame.place(relx=0.5, rely=0.5, anchor="center")
        frame.configure(width=430, height=560)

        ctk.CTkLabel(
            frame, text="Create New Account",
            font=ctk.CTkFont(size=28, weight="bold")
        ).pack(pady=(35, 10))
        ctk.CTkLabel(
            frame, text="Create a staff account to access Brewhub.",
            font=ctk.CTkFont(size=13)
        ).pack(pady=(0, 20))

        full_name = ctk.CTkEntry(frame, width=320, placeholder_text="Full Name")
        full_name.pack(pady=9)
        username = ctk.CTkEntry(frame, width=320, placeholder_text="Username")
        username.pack(pady=9)
        password = ctk.CTkEntry(frame, width=320, placeholder_text="Password", show="*")
        password.pack(pady=9)
        confirm = ctk.CTkEntry(frame, width=320, placeholder_text="Confirm Password", show="*")
        confirm.pack(pady=9)

        def create_account():
            name = full_name.get().strip()
            user = username.get().strip()
            pw = password.get()
            cpw = confirm.get()

            if not name or not user or not pw or not cpw:
                messagebox.showwarning("Create Account", "Please complete all fields.")
                return
            if len(pw) < 6:
                messagebox.showerror("Create Account", "Password must be at least 6 characters.")
                return
            if pw != cpw:
                messagebox.showerror("Create Account", "Passwords do not match.")
                return

            try:
                self.db.create_user(name, user, pw, "Staff")
                messagebox.showinfo(
                    "Account Created",
                    "Your staff account has been created. You can now log in."
                )
                self.show_login()
            except sqlite3.IntegrityError:
                messagebox.showerror("Account Exists", "That username already exists.")

        self.button(frame, "Create Account", create_account, 320).pack(pady=(18, 8))
        ctk.CTkButton(
            frame, text="← Back to Login", width=320,
            fg_color="transparent", border_width=1,
            command=self.show_login
        ).pack(pady=8)

    def show_create_customer_account(self):
        self.clear()
        frame = ctk.CTkFrame(self, corner_radius=20)
        frame.place(relx=0.5, rely=0.5, anchor="center")

        ctk.CTkLabel(
            frame, text="Create Customer Account",
            font=ctk.CTkFont(size=28, weight="bold")
        ).pack(pady=(30, 8))
        ctk.CTkLabel(
            frame, text="Register a customer account for BrewHub.",
            font=ctk.CTkFont(size=13)
        ).pack(pady=(0, 18))

        full_name = ctk.CTkEntry(frame, width=340, placeholder_text="Full Name")
        full_name.pack(pady=7)
        username = ctk.CTkEntry(frame, width=340, placeholder_text="Username")
        username.pack(pady=7)
        email = ctk.CTkEntry(frame, width=340, placeholder_text="Email (optional)")
        email.pack(pady=7)
        phone = ctk.CTkEntry(frame, width=340, placeholder_text="Phone (optional)")
        phone.pack(pady=7)
        address = ctk.CTkEntry(frame, width=340, placeholder_text="Address (optional)")
        address.pack(pady=7)
        password = ctk.CTkEntry(frame, width=340, placeholder_text="Password", show="*")
        password.pack(pady=7)
        confirm = ctk.CTkEntry(frame, width=340, placeholder_text="Confirm Password", show="*")
        confirm.pack(pady=7)

        def create_customer():
            name = full_name.get().strip()
            user = username.get().strip()
            pw = password.get()
            cpw = confirm.get()

            if not name or not user or not pw or not cpw:
                messagebox.showwarning("Create Customer Account", "Please complete the required fields.")
                return
            if len(pw) < 6:
                messagebox.showerror("Create Customer Account", "Password must be at least 6 characters.")
                return
            if pw != cpw:
                messagebox.showerror("Create Customer Account", "Passwords do not match.")
                return

            try:
                self.db.create_customer(name, user, pw, email.get(), phone.get(), address.get())
                messagebox.showinfo(
                    "Account Created",
                    "Customer account created successfully. You can now log in using your customer username and password."
                )
                self.show_login()
            except sqlite3.IntegrityError:
                messagebox.showerror("Account Exists", "That customer username already exists.")

        self.button(frame, "Create Customer Account", create_customer, 340).pack(pady=(15, 7))
        ctk.CTkButton(
            frame, text="← Back to Login", width=340,
            fg_color="transparent", border_width=1,
            command=self.show_login
        ).pack(pady=(0, 20))

    def login(self):
        username = self.login_username.get().strip()
        password = self.login_password.get()

        if not username or not password:
            messagebox.showwarning("Login", "Enter username and password.")
            return

        user = self.db.authenticate(username, password)
        if not user:
            messagebox.showerror("Login Failed", "Invalid username or password.")
            return

        self.current_user = user
        self.show_dashboard()

    def logout(self):
        if messagebox.askyesno("Logout", "Do you want to log out?"):
            self.current_user = None
            self.cart.clear()
            self.show_login()

    # -------------------- Dashboard --------------------

    def show_dashboard(self):
        self.clear()

        top = ctk.CTkFrame(self, height=70, corner_radius=0)
        top.pack(fill="x")
        top.pack_propagate(False)

        ctk.CTkLabel(
            top, text="☕ Brewhub",
            font=ctk.CTkFont(size=26, weight="bold")
        ).pack(side="left", padx=25)

        ctk.CTkLabel(
            top,
            text=f"Welcome, {self.current_user['full_name']} ({self.current_user['role']})",
            font=ctk.CTkFont(size=14),
        ).pack(side="left", padx=20)

        self.button(top, "Logout", self.logout, 100).pack(side="right", padx=20)

        nav = ctk.CTkFrame(self, corner_radius=12)
        nav.pack(fill="x", padx=20, pady=15)

        buttons = [
            ("Dashboard", self.show_dashboard),
            ("Products", self.show_products),
            ("Inventory", self.show_inventory),
            ("New Order", self.show_orders),
            ("Order Queue", self.show_order_queue),
            ("Order History", self.show_history),
            ("Sales Reports", self.show_reports),
        ]
        for text, command in buttons:
            self.button(nav, text, command, 145).pack(side="left", padx=6, pady=10)

        if self.current_user["role"] == "Admin":
            self.button(nav, "User Management", self.show_users, 145).pack(
                side="left", padx=6, pady=10
            )

        body = ctk.CTkFrame(self, fg_color="transparent")
        body.pack(fill="both", expand=True, padx=20, pady=5)

        self.title_label(body, "Dashboard").pack(anchor="w", pady=(5, 15))

        sales, orders, low, products = self.db.dashboard_stats()
        stats = [
            ("Today's Sales", f"₱{sales:,.2f}"),
            ("Today's Orders", str(orders)),
            ("Low Stock Items", str(low)),
            ("Active Products", str(products)),
        ]

        cards = ctk.CTkFrame(body, fg_color="transparent")
        cards.pack(fill="x")

        for title, value in stats:
            card = ctk.CTkFrame(cards, corner_radius=16)
            card.pack(side="left", fill="both", expand=True, padx=7)
            ctk.CTkLabel(
                card, text=title, font=ctk.CTkFont(size=15)
            ).pack(pady=(20, 5))
            ctk.CTkLabel(
                card, text=value, font=ctk.CTkFont(size=27, weight="bold")
            ).pack(pady=(0, 20))

        info = ctk.CTkFrame(body, corner_radius=16)
        info.pack(fill="both", expand=True, pady=20)
        ctk.CTkLabel(
            info,
            text="Quick Actions",
            font=ctk.CTkFont(size=20, weight="bold"),
        ).pack(pady=20)

        actions = ctk.CTkFrame(info, fg_color="transparent")
        actions.pack()
        self.button(actions, "Create New Order", self.show_orders, 200).grid(
            row=0, column=0, padx=10, pady=10
        )
        self.button(actions, "Manage Products", self.show_products, 200).grid(
            row=0, column=1, padx=10, pady=10
        )
        self.button(actions, "Check Inventory", self.show_inventory, 200).grid(
            row=1, column=0, padx=10, pady=10
        )
        self.button(actions, "Pending / Preparing Orders", self.show_order_queue, 200).grid(
            row=1, column=1, padx=10, pady=10
        )
        self.button(actions, "View Sales Reports", self.show_reports, 200).grid(
            row=2, column=0, padx=10, pady=10
        )

    # -------------------- Products --------------------

    def show_products(self):
        self.clear()
        self.build_header("Product Management")

        panel = ctk.CTkFrame(self)
        panel.pack(fill="x", padx=20, pady=10)

        self.prod_name = ctk.CTkEntry(panel, placeholder_text="Product name", width=210)
        self.prod_name.grid(row=0, column=0, padx=8, pady=12)

        self.prod_category = ctk.CTkComboBox(
            panel,
            values=["Coffee", "Cold Drinks", "Frappe", "Non-Coffee", "Pastry", "Other"],
            width=170,
        )
        self.prod_category.set("Coffee")
        self.prod_category.grid(row=0, column=1, padx=8, pady=12)

        self.prod_price = ctk.CTkEntry(panel, placeholder_text="Price", width=120)
        self.prod_price.grid(row=0, column=2, padx=8, pady=12)

        self.prod_stock = ctk.CTkEntry(panel, placeholder_text="Stock", width=120)
        self.prod_stock.grid(row=0, column=3, padx=8, pady=12)

        self.button(panel, "Add Product", self.add_product, 140).grid(
            row=0, column=4, padx=8
        )
        self.button(panel, "Update Selected", self.update_product, 150).grid(
            row=0, column=5, padx=8
        )
        self.button(panel, "Delete Product", self.delete_product, 150).grid(
            row=0, column=6, padx=8
        )

        table_frame = ctk.CTkFrame(self)
        table_frame.pack(fill="both", expand=True, padx=20, pady=10)

        self.product_tree = self.make_tree(
            table_frame,
            ("ID", "Name", "Category", "Price", "Stock"),
            (60, 260, 180, 120, 100),
        )
        self.product_tree.pack(fill="both", expand=True, padx=10, pady=10)
        self.product_tree.bind("<<TreeviewSelect>>", self.on_product_select)
        self.refresh_products()

    def add_product(self):
        try:
            name = self.prod_name.get().strip()
            category = self.prod_category.get().strip()
            price = float(self.prod_price.get())
            stock = int(self.prod_stock.get())
            if not name or price < 0 or stock < 0:
                raise ValueError
            self.db.add_product(name, category, price, stock)
            self.clear_product_inputs()
            self.refresh_products()
            messagebox.showinfo("Success", "Product added successfully.")
        except ValueError:
            messagebox.showerror("Invalid Input", "Enter a valid name, price, and stock.")

    def update_product(self):
        if self.selected_product_id is None:
            messagebox.showwarning("Update", "Select a product first.")
            return
        try:
            name = self.prod_name.get().strip()
            category = self.prod_category.get().strip()
            price = float(self.prod_price.get())
            stock = int(self.prod_stock.get())
            if not name or price < 0 or stock < 0:
                raise ValueError
            self.db.update_product(
                self.selected_product_id, name, category, price, stock
            )
            self.refresh_products()
            messagebox.showinfo("Success", "Product updated successfully.")
        except ValueError:
            messagebox.showerror("Invalid Input", "Enter valid product information.")

    def delete_product(self):
        if self.selected_product_id is None:
            messagebox.showwarning("Delete", "Select a product first.")
            return
        if messagebox.askyesno("Delete Product", "Delete the selected product?"):
            product_name = self.prod_name.get().strip() or "selected product"
            self.db.delete_product(self.selected_product_id)
            self.selected_product_id = None
            self.clear_product_inputs()
            self.refresh_products()
            messagebox.showinfo("Deleted", f"{product_name} was deleted successfully.")

    def on_product_select(self, _event=None):
        selected = self.product_tree.selection()
        if not selected:
            return
        values = self.product_tree.item(selected[0], "values")
        self.selected_product_id = int(values[0])
        self.prod_name.delete(0, "end")
        self.prod_name.insert(0, values[1])
        self.prod_category.set(values[2])
        self.prod_price.delete(0, "end")
        self.prod_price.insert(0, values[3])
        self.prod_stock.delete(0, "end")
        self.prod_stock.insert(0, values[4])

    def clear_product_inputs(self):
        for widget in (self.prod_name, self.prod_price, self.prod_stock):
            widget.delete(0, "end")
        self.prod_category.set("Coffee")

    def refresh_products(self):
        if not hasattr(self, "product_tree"):
            return
        for row in self.product_tree.get_children():
            self.product_tree.delete(row)
        for p in self.db.all_products():
            self.product_tree.insert(
                "", "end",
                values=(p["id"], p["name"], p["category"],
                        f"₱{p['price']:,.2f}", p["stock"])
            )

    # -------------------- Inventory --------------------

    def show_inventory(self):
        self.clear()
        self.build_header("Inventory Management")

        controls = ctk.CTkFrame(self)
        controls.pack(fill="x", padx=20, pady=10)

        self.inventory_product = ctk.CTkComboBox(controls, values=[], width=300)
        self.inventory_product.grid(row=0, column=0, padx=10, pady=12)

        self.inventory_quantity = ctk.CTkEntry(
            controls, placeholder_text="New quantity", width=150
        )
        self.inventory_quantity.grid(row=0, column=1, padx=10, pady=12)

        self.button(controls, "Update Stock", self.update_inventory, 150).grid(
            row=0, column=2, padx=10
        )

        self.inventory_tree = self.make_tree(
            self,
            ("ID", "Product", "Category", "Quantity", "Status"),
            (60, 300, 180, 120, 160),
        )
        self.inventory_tree.pack(fill="both", expand=True, padx=20, pady=10)
        self.refresh_inventory()

    def refresh_inventory(self):
        rows = self.db.all_products()
        names = [f"{p['id']} - {p['name']}" for p in rows]
        self.inventory_product.configure(values=names)
        if names:
            self.inventory_product.set(names[0])

        for row in self.inventory_tree.get_children():
            self.inventory_tree.delete(row)

        for p in rows:
            status = "LOW STOCK" if p["stock"] <= 5 else "In Stock"
            self.inventory_tree.insert(
                "", "end",
                values=(p["id"], p["name"], p["category"], p["stock"], status)
            )

    def update_inventory(self):
        try:
            selected = self.inventory_product.get()
            product_id = int(selected.split(" - ")[0])
            quantity = int(self.inventory_quantity.get())
            if quantity < 0:
                raise ValueError
            self.db.update_stock(product_id, quantity)
            self.inventory_quantity.delete(0, "end")
            self.refresh_inventory()
            messagebox.showinfo("Success", "Inventory updated.")
        except (ValueError, IndexError):
            messagebox.showerror("Invalid Input", "Select a product and enter a valid quantity.")

    # -------------------- Order Processing --------------------

    def show_orders(self):
        self.clear()
        self.build_header("Order Processing")

        main = ctk.CTkFrame(self, fg_color="transparent")
        main.pack(fill="both", expand=True, padx=20, pady=10)

        left = ctk.CTkFrame(main)
        left.pack(side="left", fill="both", expand=True, padx=(0, 10))

        right = ctk.CTkFrame(main, width=390)
        right.pack(side="right", fill="both", padx=(10, 0))
        right.pack_propagate(False)

        ctk.CTkLabel(
            left, text="Available Products",
            font=ctk.CTkFont(size=20, weight="bold")
        ).pack(pady=12)

        product_scroll = ctk.CTkScrollableFrame(left)
        product_scroll.pack(fill="both", expand=True, padx=10, pady=10)
        self.product_scroll = product_scroll

        # Product cards are displayed in a responsive 4-column grid.
        # This keeps the cards visible on normal 1000-1200px desktop windows.
        self.refresh_order_products()

        refresh_products_btn = self.button(
            left, "Refresh Products", self.refresh_order_products, 180
        )
        refresh_products_btn.pack(pady=(0, 10))

        ctk.CTkLabel(
            right, text="Current Order",
            font=ctk.CTkFont(size=20, weight="bold")
        ).pack(pady=15)

        self.customer_entry = ctk.CTkEntry(
            right, placeholder_text="Customer name", width=320
        )
        self.customer_entry.pack(pady=8)

        self.cart_frame = ctk.CTkScrollableFrame(right, height=330)
        self.cart_frame.pack(fill="both", expand=True, padx=10, pady=10)

        self.total_label = ctk.CTkLabel(
            right, text="Total: ₱0.00",
            font=ctk.CTkFont(size=22, weight="bold")
        )
        self.total_label.pack(pady=10)

        self.button(right, "Place Order", self.place_order, 320).pack(pady=10)
        self.button(right, "Clear Cart", self.clear_cart, 320).pack(pady=5)

        self.refresh_cart()

    def refresh_order_products(self):
        """Reload active products from the database into the New Order screen."""
        if not hasattr(self, "product_scroll"):
            return

        for widget in self.product_scroll.winfo_children():
            widget.destroy()

        self.product_images = {}
        for column in range(4):
            self.product_scroll.grid_columnconfigure(column, weight=1)

        products = self.db.products()
        if not products:
            ctk.CTkLabel(
                self.product_scroll,
                text="No active products available. Add products in Product Management.",
                font=ctk.CTkFont(size=16),
            ).grid(row=0, column=0, columnspan=4, padx=20, pady=40)
            return

        for index, p in enumerate(products):
            row, column = divmod(index, 4)
            self.add_product_card(self.product_scroll, p, row, column)

    def add_product_card(self, parent, p, row=0, column=0):
        frame = ctk.CTkFrame(parent, corner_radius=12, width=185, height=300)
        frame.grid(row=row, column=column, padx=6, pady=6, sticky="n")
        frame.grid_propagate(False)

        # Load the product photo from product_images/<product_name>.png.
        # The image is optional; if it is missing, the card still works.
        image_key = p["name"].strip().lower().replace(" ", "_")
        image_path = Path(PRODUCT_IMAGE_DIR) / f"{image_key}.png"
        image_loaded = False
        try:
            if image_path.exists():
                source = Image.open(image_path).convert("RGB")
                source = ImageOps.fit(source, (165, 145), method=Image.LANCZOS)
                self.product_images[p["id"]] = ctk.CTkImage(
                    light_image=source,
                    dark_image=source,
                    size=(165, 145),
                )
                ctk.CTkLabel(frame, image=self.product_images[p["id"]], text="").pack(
                    padx=8, pady=(8, 4)
                )
                image_loaded = True
        except Exception:
            image_loaded = False

        if not image_loaded:
            ctk.CTkLabel(
                frame, text="☕",
                font=ctk.CTkFont(size=45),
                height=145
            ).pack(fill="x", padx=8, pady=(8, 4))

        ctk.CTkLabel(
            frame, text=p["name"],
            font=ctk.CTkFont(size=15, weight="bold"),
            anchor="w"
        ).pack(fill="x", padx=10, pady=(2, 0))

        ctk.CTkLabel(
            frame, text=f"{p['category']}  •  ₱{p['price']:,.2f}",
            text_color="#d9d9d9",
            anchor="w"
        ).pack(fill="x", padx=10, pady=(2, 0))

        stock_text = f"Stock: {p['stock']}"
        ctk.CTkLabel(
            frame, text=stock_text,
            text_color="gray", anchor="w"
        ).pack(fill="x", padx=10, pady=(1, 3))

        btn = self.button(
            frame, "🛒  Add to Cart",
            lambda product_id=p["id"]: self.add_to_cart(product_id),
            155
        )
        btn.pack(pady=(2, 8))

        if p["stock"] <= 0:
            btn.configure(state="disabled")

    def add_to_cart(self, product_id):
        product = next(
            (p for p in self.db.products() if p["id"] == product_id), None
        )
        if not product:
            return

        current = self.cart.get(product_id, 0)
        if current >= product["stock"]:
            messagebox.showwarning("Stock", "You cannot add more than available stock.")
            return

        self.cart[product_id] = current + 1
        self.refresh_cart()

    def change_cart_quantity(self, product_id, delta):
        if product_id not in self.cart:
            return
        product = next(
            (p for p in self.db.products() if p["id"] == product_id), None
        )
        new_qty = self.cart[product_id] + delta
        if new_qty <= 0:
            del self.cart[product_id]
        elif product and new_qty <= product["stock"]:
            self.cart[product_id] = new_qty
        else:
            messagebox.showwarning("Stock", "Quantity exceeds available stock.")
        self.refresh_cart()

    def refresh_cart(self):
        if not hasattr(self, "cart_frame"):
            return

        for w in self.cart_frame.winfo_children():
            w.destroy()

        total = 0
        for product_id, quantity in self.cart.items():
            product = next(
                (p for p in self.db.products() if p["id"] == product_id), None
            )
            if not product:
                continue
            subtotal = product["price"] * quantity
            total += subtotal

            row = ctk.CTkFrame(self.cart_frame)
            row.pack(fill="x", pady=4)

            ctk.CTkLabel(row, text=product["name"], width=130, anchor="w").pack(
                side="left", padx=5
            )
            ctk.CTkButton(
                row, text="-", width=30,
                command=lambda pid=product_id: self.change_cart_quantity(pid, -1)
            ).pack(side="left")
            ctk.CTkLabel(row, text=str(quantity), width=35).pack(side="left")
            ctk.CTkButton(
                row, text="+", width=30,
                command=lambda pid=product_id: self.change_cart_quantity(pid, 1)
            ).pack(side="left")
            ctk.CTkLabel(row, text=f"₱{subtotal:,.2f}", width=90).pack(
                side="right", padx=5
            )

        self.total_label.configure(text=f"Total: ₱{total:,.2f}")

    def clear_cart(self):
        self.cart.clear()
        self.refresh_cart()

    def place_order(self):
        customer = self.customer_entry.get().strip()
        if not customer:
            messagebox.showwarning("Order", "Enter customer name.")
            return
        if not self.cart:
            messagebox.showwarning("Order", "Add products to the order.")
            return

        order = Order(customer)
        for product_id, quantity in self.cart.items():
            p = next((x for x in self.db.products() if x["id"] == product_id), None)
            if p:
                product = Product(p["id"], p["name"], p["category"], p["price"], p["stock"])
                order.add_item(product, quantity)

        try:
            order_id, total = self.order_manager.save(order, self.current_user["id"])
            messagebox.showinfo(
                "Order Placed",
                f"Order #{order_id} has been placed and is now PENDING.\n\nTotal: ₱{total:,.2f}\n\nOpen Order Queue to start preparing it."
            )
            self.cart.clear()
            self.customer_entry.delete(0, "end")
            self.show_order_queue()
        except ValueError as exc:
            messagebox.showerror("Order Error", str(exc))

    # -------------------- Pending / Preparing Orders --------------------

    def show_order_queue(self):
        self.clear()
        self.build_header("Order Queue")

        top = ctk.CTkFrame(self)
        top.pack(fill="x", padx=20, pady=10)
        ctk.CTkLabel(
            top,
            text="Pending and Preparing Orders",
            font=ctk.CTkFont(size=22, weight="bold"),
        ).pack(side="left", padx=15, pady=12)
        ctk.CTkLabel(
            top,
            text="New orders automatically enter Pending status.",
            text_color="gray",
        ).pack(side="left", padx=10)

        frame = ctk.CTkFrame(self)
        frame.pack(fill="both", expand=True, padx=20, pady=10)

        columns = ("Order ID", "Customer", "Total", "Date/Time", "Status", "Staff")
        self.queue_tree = self.make_tree(
            frame, columns, (90, 220, 120, 190, 130, 170)
        )
        self.queue_tree.pack(fill="both", expand=True, padx=10, pady=10)

        controls = ctk.CTkFrame(self, fg_color="transparent")
        controls.pack(pady=(0, 15))

        self.button(controls, "Start Preparing", self.start_selected_order, 180).pack(
            side="left", padx=8
        )
        self.button(controls, "Mark Completed", self.complete_selected_order, 180).pack(
            side="left", padx=8
        )
        self.button(controls, "Delete Order", self.delete_selected_order, 160).pack(
            side="left", padx=8
        )
        self.button(controls, "Refresh Queue", self.show_order_queue, 150).pack(
            side="left", padx=8
        )

        self.refresh_order_queue()

    def refresh_order_queue(self):
        if not hasattr(self, "queue_tree"):
            return
        for item in self.queue_tree.get_children():
            self.queue_tree.delete(item)
        for row in self.db.active_orders():
            self.queue_tree.insert(
                "", "end",
                values=(
                    row["id"], row["customer_name"],
                    f"₱{row['total']:,.2f}", row["created_at"],
                    row["status"], row["staff"],
                )
            )

    def _selected_queue_order(self):
        selected = self.queue_tree.selection() if hasattr(self, "queue_tree") else ()
        if not selected:
            messagebox.showwarning("Order Queue", "Select an order first.")
            return None
        values = self.queue_tree.item(selected[0], "values")
        return int(values[0]), values[4]

    def start_selected_order(self):
        selected = self._selected_queue_order()
        if not selected:
            return
        order_id, status = selected
        if status == "Preparing":
            messagebox.showinfo("Order Queue", f"Order #{order_id} is already being prepared.")
            return
        try:
            self.db.update_order_status(order_id, "Preparing")
            self.refresh_order_queue()
        except ValueError as exc:
            messagebox.showerror("Order Queue", str(exc))

    def complete_selected_order(self):
        selected = self._selected_queue_order()
        if not selected:
            return
        order_id, status = selected
        if status != "Preparing":
            messagebox.showwarning(
                "Order Queue",
                "Start preparing the order before marking it completed."
            )
            return
        try:
            self.db.update_order_status(order_id, "Completed")
            messagebox.showinfo("Order Completed", f"Order #{order_id} is now completed.")
            self.refresh_order_queue()
        except ValueError as exc:
            messagebox.showerror("Order Queue", str(exc))

    def delete_selected_order(self):
        """Allow Staff/Admin to cancel an accidental active order."""
        if self.current_user["role"] not in ("Staff", "Admin"):
            messagebox.showerror(
                "Access Denied",
                "Only Staff or Admin accounts can delete orders."
            )
            return

        selected = self._selected_queue_order()
        if not selected:
            return
        order_id, status = selected

        if status == "Completed":
            messagebox.showwarning(
                "Delete Order",
                "Completed orders cannot be deleted."
            )
            return

        if not messagebox.askyesno(
            "Delete Order",
            f"Delete Order #{order_id}?\n\n"
            "This is for accidentally placed orders.\n"
            "The order will be removed, its items will be removed, "
            "and the product stock will be restored.\n\n"
            "This action cannot be undone."
        ):
            return

        try:
            self.db.delete_order(order_id)
            messagebox.showinfo(
                "Order Deleted",
                f"Order #{order_id} was deleted successfully.\n\n"
                "The stock has been restored and the sale was removed."
            )
            self.refresh_order_queue()
        except ValueError as exc:
            messagebox.showerror("Delete Order", str(exc))

    # -------------------- Order History --------------------

    def show_history(self):
        self.clear()
        self.build_header("Order History")

        frame = ctk.CTkFrame(self)
        frame.pack(fill="both", expand=True, padx=20, pady=10)

        self.history_tree = self.make_tree(
            frame,
            ("Order ID", "Customer", "Total", "Date/Time", "Status", "Staff"),
            (90, 220, 120, 190, 120, 170),
        )
        self.history_tree.pack(fill="both", expand=True, padx=10, pady=10)
        self.history_tree.bind("<Double-1>", self.show_order_details)

        for row in self.db.order_history():
            self.history_tree.insert(
                "", "end",
                values=(
                    row["id"], row["customer_name"],
                    f"₱{row['total']:,.2f}",
                    row["created_at"], row["status"], row["staff"]
                )
            )

        ctk.CTkLabel(
            self, text="Double-click an order to view its item details.",
            text_color="gray"
        ).pack(pady=5)

    def show_order_details(self, _event=None):
        selected = self.history_tree.selection()
        if not selected:
            return
        order_id = int(self.history_tree.item(selected[0], "values")[0])
        items = self.db.order_items(order_id)

        text = []
        for item in items:
            text.append(
                f"{item['name']} x {item['quantity']} = ₱{item['subtotal']:,.2f}"
            )
        messagebox.showinfo(
            f"Order #{order_id}",
            "\n".join(text) if text else "No order items found."
        )

    # -------------------- Sales Reports --------------------

    def show_reports(self):
        self.clear()
        self.build_header("Sales Reports")

        controls = ctk.CTkFrame(self)
        controls.pack(fill="x", padx=20, pady=10)

        ctk.CTkLabel(controls, text="Start Date (YYYY-MM-DD)").pack(
            side="left", padx=(15, 5)
        )
        self.report_start = ctk.CTkEntry(controls, width=140)
        self.report_start.pack(side="left", padx=5)
        self.report_start.insert(0, date.today().replace(day=1).isoformat())

        ctk.CTkLabel(controls, text="End Date").pack(side="left", padx=(15, 5))
        self.report_end = ctk.CTkEntry(controls, width=140)
        self.report_end.pack(side="left", padx=5)
        self.report_end.insert(0, date.today().isoformat())

        self.button(controls, "Generate Report", self.generate_report, 160).pack(
            side="left", padx=15
        )

        self.report_tree = self.make_tree(
            self,
            ("Date", "Orders", "Sales"),
            (200, 160, 200),
        )
        self.report_tree.pack(fill="both", expand=True, padx=20, pady=10)

        self.report_total = ctk.CTkLabel(
            self, text="Total Sales: ₱0.00",
            font=ctk.CTkFont(size=22, weight="bold")
        )
        self.report_total.pack(pady=15)

        self.generate_report()

    def generate_report(self):
        try:
            start = self.report_start.get().strip()
            end = self.report_end.get().strip()
            datetime.strptime(start, "%Y-%m-%d")
            datetime.strptime(end, "%Y-%m-%d")
            if start > end:
                raise ValueError

            rows = self.report_generator.period(start, end)
            for item in self.report_tree.get_children():
                self.report_tree.delete(item)

            total = 0
            for row in rows:
                total += row["total_sales"] or 0
                self.report_tree.insert(
                    "", "end",
                    values=(row["sale_date"], row["order_count"],
                            f"₱{row['total_sales']:,.2f}")
                )
            self.report_total.configure(text=f"Total Sales: ₱{total:,.2f}")
        except ValueError:
            messagebox.showerror(
                "Invalid Date",
                "Use valid dates in YYYY-MM-DD format."
            )

    # -------------------- User Management --------------------

    def show_users(self):
        if self.current_user["role"] != "Admin":
            messagebox.showerror("Access Denied", "Administrator access is required.")
            return

        self.clear()
        self.build_header("User Management")

        panel = ctk.CTkFrame(self)
        panel.pack(fill="x", padx=20, pady=10)

        name = ctk.CTkEntry(panel, placeholder_text="Full name", width=220)
        name.grid(row=0, column=0, padx=8, pady=12)
        username = ctk.CTkEntry(panel, placeholder_text="Username", width=180)
        username.grid(row=0, column=1, padx=8, pady=12)
        password = ctk.CTkEntry(panel, placeholder_text="Password", show="*", width=180)
        password.grid(row=0, column=2, padx=8, pady=12)
        role = ctk.CTkComboBox(panel, values=["Staff", "Admin", "Customer"], width=120)
        role.set("Staff")
        role.grid(row=0, column=3, padx=8, pady=12)

        def add_user():
            try:
                if not name.get().strip() or not username.get().strip() or len(password.get()) < 6:
                    raise ValueError
                selected_role = role.get().strip()
                if selected_role == "Customer":
                    self.db.create_customer(
                        name.get(), username.get(), password.get()
                    )
                else:
                    self.db.create_user(
                        name.get(), username.get(), password.get(), selected_role
                    )
                refresh()
                for w in (name, username, password):
                    w.delete(0, "end")
                messagebox.showinfo("Success", "User created.")
            except ValueError:
                messagebox.showerror("Invalid Input", "Use a name, username, and password of at least 6 characters.")
            except sqlite3.IntegrityError:
                messagebox.showerror("User Exists", "That username already exists.")

        self.button(panel, "Create User", add_user, 130).grid(
            row=0, column=4, padx=10
        )

        def delete_selected_user():
            selected = tree.selection()
            if not selected:
                messagebox.showwarning("Delete Account", "Select an account first.")
                return

            values = tree.item(selected[0], "values")
            user_id = int(values[0])
            username_value = values[2]
            role_value = values[3]

            # Prevent an administrator from deleting the account currently in use.
            if user_id == self.current_user["id"]:
                messagebox.showwarning(
                    "Delete Account",
                    "You cannot delete the account you are currently logged in with."
                )
                return

            if not messagebox.askyesno(
                "Delete Account",
                f"Delete the {role_value} account '{username_value}'?\n\n"
                "This cannot be undone.",
            ):
                return

            try:
                self.db.delete_user(user_id)
                refresh()
                messagebox.showinfo("Delete Account", "Account deleted successfully.")
            except Exception as exc:
                messagebox.showerror("Delete Account", f"Could not delete the account.\n{exc}")

        self.button(panel, "Delete Selected", delete_selected_user, 150).grid(
            row=0, column=5, padx=10
        )

        def delete_all_accounts():
            rows = self.db.conn.execute("SELECT id, username, role FROM users").fetchall()
            deletable = [row for row in rows if row["id"] != self.current_user["id"]]
            if not deletable:
                messagebox.showwarning("Delete Accounts", "There are no other accounts to delete.")
                return

            if not messagebox.askyesno(
                "Delete All Accounts",
                "Delete ALL other Admin, Staff, and Customer accounts?\n\n"
                "Your currently logged-in account will be kept. This cannot be undone.",
            ):
                return

            try:
                self.db.conn.execute(
                    """DELETE FROM customers
                       WHERE username IN
                         (SELECT username FROM users WHERE id != ?)""",
                    (self.current_user["id"],),
                )
                # Preserve historical orders while removing accounts.
                self.db.conn.execute(
                    "UPDATE orders SET user_id=NULL WHERE user_id != ?",
                    (self.current_user["id"],),
                )
                self.db.conn.execute(
                    "DELETE FROM users WHERE id != ?", (self.current_user["id"],)
                )
                self.db.conn.commit()
                refresh()
                messagebox.showinfo("Delete Accounts", "All other Admin, Staff, and Customer accounts were deleted.")
            except Exception as exc:
                self.db.conn.rollback()
                messagebox.showerror("Delete Accounts", f"Could not delete the accounts.\n{exc}")

        self.button(panel, "Delete All Others", delete_all_accounts, 150).grid(
            row=0, column=6, padx=10
        )

        tree = self.make_tree(
            self, ("ID", "Full Name", "Username", "Role"),
            (70, 300, 220, 120)
        )
        tree.pack(fill="both", expand=True, padx=20, pady=10)

        def refresh():
            for item in tree.get_children():
                tree.delete(item)
            rows = self.db.conn.execute(
                "SELECT id,full_name,username,role FROM users ORDER BY id"
            ).fetchall()
            for row in rows:
                tree.insert("", "end", values=tuple(row))

        refresh()

    # -------------------- Shared widgets --------------------

    def build_header(self, title):
        bar = ctk.CTkFrame(self, height=70, corner_radius=0)
        bar.pack(fill="x")
        bar.pack_propagate(False)

        ctk.CTkLabel(
            bar, text=title,
            font=ctk.CTkFont(size=25, weight="bold")
        ).pack(side="left", padx=25)

        ctk.CTkButton(
            bar, text="← Dashboard", width=130,
            command=self.show_dashboard
        ).pack(side="right", padx=20)

    def make_tree(self, parent, columns, widths):
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except Exception:
            pass

        style.configure(
            "Treeview",
            rowheight=32,
            font=("Segoe UI", 10),
            background="#202020",
            foreground="white",
            fieldbackground="#202020",
        )
        style.configure(
            "Treeview.Heading",
            font=("Segoe UI", 10, "bold"),
        )

        tree = ttk.Treeview(parent, columns=columns, show="headings")
        for column, width in zip(columns, widths):
            tree.heading(column, text=column)
            tree.column(column, width=width, anchor="center")
        return tree

    def on_close(self):
        self.db.close()
        self.destroy()


if __name__ == "__main__":
    app = BrewHubApp()
    app.mainloop()
