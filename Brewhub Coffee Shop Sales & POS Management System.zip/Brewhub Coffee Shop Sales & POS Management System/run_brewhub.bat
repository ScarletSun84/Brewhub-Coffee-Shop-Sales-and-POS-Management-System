@echo off
setlocal
cd /d "%~dp0"
echo =============================================
echo   BrewHub Coffee Shop Sales & POS Management
echo =============================================
echo.
where py >nul 2>nul
if %errorlevel%==0 (
  set "PYTHON=py"
) else (
  where python >nul 2>nul
  if errorlevel 1 (
    echo ERROR: Python was not found. Install Python 3.10 or newer from python.org.
    echo During installation, select "Add Python to PATH".
    pause
    exit /b 1
  )
  set "PYTHON=python"
)
echo [1/2] Installing required Python packages, including Flask...
%PYTHON% -m pip install -r requirements_BrewHub.txt
if errorlevel 1 (
  echo.
  echo ERROR: Could not install the required packages.
  echo Check your internet connection and Python/pip installation, then try again.
  pause
  exit /b 1
)
echo.
echo [2/2] Starting BrewHub. Keep this window open while using the app.
%PYTHON% Python\run.py
if errorlevel 1 (
  echo.
  echo BrewHub stopped because of an error. Check the message above.
  pause
)
endlocal
