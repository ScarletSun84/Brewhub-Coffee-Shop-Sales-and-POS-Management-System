# BrewHub Coffee Shop Sales & POS Management System

This build uses a browser-based frontend, a **Python Flask backend**, and an SQLite database. Flask is already integrated in `Python/api.py`; the launcher installs it from `requirements_BrewHub.txt` before starting the app.

## Folder layout
- `main/index.html` — frontend pages and layout
- `main/style.css` — frontend styling, including centered “Welcome to BrewHub” heading
- `main/script.js` — browser-side interactions and API calls, including account registration
- `Python/run.py` — starts the Flask backend and opens the browser
- `Python/api.py` — Flask REST API, login sessions, registration, products, inventory, orders, and sales reports
- `Python/database.py` — SQLite database access layer
- `Python/brewhub.db` — SQLite database
- `requirements_BrewHub.txt` — Python dependencies, including Flask
- `run_brewhub.bat` — Windows launcher that installs dependencies and starts BrewHub
- `product_images/` — product photos supplied in the uploaded `image.zip`
- `brewhub_logo.png` — BrewHub logo
- `desktop_legacy/` — previous Python desktop GUI kept as a backup

## Start BrewHub on Windows (recommended)
1. Extract the ZIP file.
2. Install Python 3.10 or newer if it is not already installed. During setup, select **Add Python to PATH**.
3. Double-click `run_brewhub.bat`. It installs packages listed in `requirements_BrewHub.txt`, including Flask, and starts the application.
4. Keep the terminal window open while using BrewHub. The browser should open at `http://127.0.0.1:5000`.

## Start from VS Code instead
Open the extracted project folder in VS Code, then run these commands in the terminal:

```powershell
py -m pip install -r requirements_BrewHub.txt
py Python/run.py
```

If the `py` command is not available, try `python` instead.

## Account setup
If the database has no accounts, use **Create an account** on the login screen to create the first Admin account. After signing in as Admin, use **Admin Accounts** to create additional Admin and Staff accounts. Customer registration is available from the login screen.

## Important notes
- Do not double-click `main/index.html`; use the launcher so Flask can serve the frontend and `/api` endpoints.
- Keep the launcher/terminal window open while using the app.
- This is intended for local use. Do not expose the development server directly to the internet without adding deployment security and HTTPS.


Order management: administrators can delete Pending orders from Orders. The system returns reserved quantities to product stock and inventory. Preparing and Completed orders cannot be deleted, preserving operational and sales history.


## Modern refresh
- Refreshed the workspace with cleaner navigation, consistent spacing, responsive cards, accessible focus states, and clearer status/stock indicators.
- Product photos appear in the POS menu, Product Catalog, and Inventory screens.
- Order deletion remains restricted to Pending orders and restores the reserved stock quantities atomically.
- The included database starts with an empty order queue, no order items, no sales, and no customer profiles; the existing Admin account, products, and inventory are retained.
