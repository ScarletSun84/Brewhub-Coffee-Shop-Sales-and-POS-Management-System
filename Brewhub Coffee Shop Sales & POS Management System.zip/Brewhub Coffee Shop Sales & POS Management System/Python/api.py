"""Flask REST API for BrewHub web frontend.

Run from the project root with: py Python/run.py
SQLite data remains in Python/brewhub.db.
"""
from __future__ import annotations

import os
import sys
from datetime import date
from pathlib import Path
from functools import wraps

from flask import Flask, jsonify, request, send_from_directory, session

PROJECT_ROOT = Path(__file__).resolve().parent.parent
MAIN_DIR = PROJECT_ROOT / "main"
PYTHON_DIR = PROJECT_ROOT / "Python"
if str(PYTHON_DIR) not in sys.path:
    sys.path.insert(0, str(PYTHON_DIR))

from database import Database

app = Flask(__name__, static_folder=None)
app.secret_key = os.environ.get("BREWHUB_SECRET_KEY", "change-this-local-dev-secret")
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax")


def get_db():
    return Database()


def row_dict(row):
    return dict(row) if row is not None else None


def login_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        if not session.get("user"):
            return jsonify(error="Please sign in first."), 401
        return fn(*args, **kwargs)
    return wrapped


def admin_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        user = session.get("user")
        if not user:
            return jsonify(error="Please sign in first."), 401
        if user.get("role", "").lower() not in ("admin", "manager"):
            return jsonify(error="Admin or manager access is required."), 403
        return fn(*args, **kwargs)
    return wrapped


@app.after_request
def no_cache(response):
    response.headers["Cache-Control"] = "no-store"
    # Allow the frontend to be opened from VS Code Live Server during development.
    # Credentials are needed so Flask login sessions work across ports.
    origin = request.headers.get("Origin", "")
    allowed_origins = {
        "http://127.0.0.1:5500",
        "http://localhost:5500",
    }
    if origin in allowed_origins:
        response.headers["Access-Control-Allow-Origin"] = origin
        response.headers["Access-Control-Allow-Credentials"] = "true"
        response.headers["Access-Control-Allow-Headers"] = "Content-Type"
        response.headers["Access-Control-Allow-Methods"] = "GET, POST, PUT, PATCH, DELETE, OPTIONS"
        response.headers["Vary"] = "Origin"
    return response


@app.get("/")
def index():
    return send_from_directory(MAIN_DIR, "index.html")


@app.get("/<path:filename>")
def frontend_files(filename):
    # Only expose frontend files from main/; no arbitrary project file reads.
    if filename in {"index.html", "style.css", "script.js"}:
        return send_from_directory(MAIN_DIR, filename)
    if filename.startswith("product_images/"):
        return send_from_directory(PROJECT_ROOT / "product_images", filename.split("/", 1)[1])
    if filename == "brewhub_logo.png":
        return send_from_directory(PROJECT_ROOT, filename)
    return jsonify(error="Not found."), 404


@app.post("/api/login")
def login():
    payload = request.get_json(silent=True) or {}
    username = str(payload.get("username", "")).strip()
    password = str(payload.get("password", ""))
    if not username or not password:
        return jsonify(error="Enter your username and password."), 400
    db = get_db()
    try:
        user = db.authenticate(username, password)
        if not user:
            return jsonify(error="Invalid username or password."), 401
        user_data = {"id": user["id"], "full_name": user["full_name"], "username": user["username"], "role": user["role"]}
        session.clear()
        session["user"] = user_data
        return jsonify(user=user_data)
    finally:
        db.close()


@app.get("/api/account-status")
def account_status():
    db = get_db()
    try:
        return jsonify(has_users=db.user_count() > 0, signed_in=bool(session.get("user")),
                       can_manage_accounts=session.get("user", {}).get("role", "").lower() == "admin")
    finally:
        db.close()


@app.post("/api/register")
def register_account():
    payload = request.get_json(silent=True) or {}
    full_name = str(payload.get("full_name", "")).strip()
    username = str(payload.get("username", "")).strip()
    password = str(payload.get("password", ""))
    role = str(payload.get("role", "Customer")).strip().title()
    if not full_name or len(username) < 3 or len(password) < 6:
        return jsonify(error="Enter your full name, a username of at least 3 characters, and a password of at least 6 characters."), 400
    if role not in {"Admin", "Staff", "Customer"}:
        return jsonify(error="Choose Admin, Staff, or Customer."), 400
    db = get_db()
    try:
        signed_user = session.get("user") or {}
        # Public registration is Customer-only. Admin and Staff accounts can
        # only be created by an authenticated Admin from the Admin Accounts page.
        if role in {"Admin", "Staff"} and signed_user.get("role", "").lower() != "admin":
            return jsonify(error="Public registration is for Customer accounts only. Sign in as Admin to create Admin or Staff accounts."), 403
        if role == "Customer":
            db.create_customer(full_name, username, password,
                               str(payload.get("email", "")), str(payload.get("phone", "")),
                               str(payload.get("address", "")))
        else:
            db.create_user(full_name, username, password, role)
        return jsonify(ok=True, message=f"{role} account created successfully."), 201
    except Exception as exc:
        import sqlite3
        if isinstance(exc, sqlite3.IntegrityError):
            return jsonify(error="That username already exists. Please choose another."), 409
        app.logger.exception("Account registration failed")
        return jsonify(error="Could not create the account. Please try again."), 500
    finally:
        db.close()


@app.post("/api/logout")
def logout():
    session.clear()
    return jsonify(ok=True)


@app.get("/api/me")
def me():
    if not session.get("user"):
        return jsonify(user=None), 200
    return jsonify(user=session["user"])


@app.get("/api/dashboard")
@login_required
def dashboard():
    db = get_db()
    try:
        sales, orders, low, products = db.dashboard_stats()
        return jsonify(sales=sales, orders=orders, low_stock=low, products=products)
    finally:
        db.close()


@app.get("/api/products")
@login_required
def products():
    db = get_db()
    try:
        return jsonify([dict(p) for p in db.products()])
    finally:
        db.close()


@app.post("/api/products")
@admin_required
def add_product():
    payload = request.get_json(silent=True) or {}
    try:
        name = str(payload.get("name", "")).strip()
        category = str(payload.get("category", "")).strip()
        price = float(payload.get("price", 0))
        stock = int(payload.get("stock", 0))
        if not name or not category or price <= 0 or stock < 0:
            raise ValueError("Enter a name, category, positive price, and non-negative stock.")
        db = get_db()
        try:
            db.add_product(name, category, price, stock)
            return jsonify(ok=True), 201
        finally:
            db.close()
    except (ValueError, TypeError) as exc:
        return jsonify(error=str(exc)), 400


@app.put("/api/products/<int:product_id>")
@admin_required
def edit_product(product_id):
    payload = request.get_json(silent=True) or {}
    try:
        name = str(payload.get("name", "")).strip()
        category = str(payload.get("category", "")).strip()
        price = float(payload.get("price", 0))
        stock = int(payload.get("stock", 0))
        if not name or not category or price <= 0 or stock < 0:
            raise ValueError("Enter a name, category, positive price, and non-negative stock.")
        db = get_db()
        try:
            db.update_product(product_id, name, category, price, stock)
            return jsonify(ok=True)
        finally:
            db.close()
    except (ValueError, TypeError) as exc:
        return jsonify(error=str(exc)), 400


@app.delete("/api/products/<int:product_id>")
@admin_required
def deactivate_product(product_id):
    db = get_db()
    try:
        db.delete_product(product_id)
        return jsonify(ok=True)
    except ValueError as exc:
        return jsonify(error=str(exc)), 404
    finally:
        db.close()


@app.put("/api/inventory/<int:product_id>")
@admin_required
def update_inventory(product_id):
    payload = request.get_json(silent=True) or {}
    try:
        quantity = int(payload.get("quantity"))
        db = get_db()
        try:
            db.update_stock(product_id, quantity)
            return jsonify(ok=True)
        finally:
            db.close()
    except (ValueError, TypeError) as exc:
        return jsonify(error=str(exc)), 400


@app.get("/api/orders")
@login_required
def orders():
    db = get_db()
    try:
        user = session.get("user") or {}
        if str(user.get("role", "")).lower() == "customer":
            rows = db.conn.execute("SELECT id, customer_name, total, created_at, status, NULL AS staff FROM orders WHERE user_id=? ORDER BY id DESC", (user["id"],)).fetchall()
            return jsonify([dict(o) for o in rows])
        return jsonify([dict(o) for o in db.order_history()])
    finally:
        db.close()


@app.post("/api/orders")
@login_required
def create_order():
    payload = request.get_json(silent=True) or {}
    customer_name = str(payload.get("customer_name", "Walk-in Customer")).strip() or "Walk-in Customer"
    raw_items = payload.get("items")
    if not isinstance(raw_items, list) or not raw_items:
        return jsonify(error="Add at least one product to the order."), 400
    cart = {}
    try:
        for item in raw_items:
            product_id = int(item["product_id"])
            quantity = int(item["quantity"])
            if quantity <= 0:
                raise ValueError("Item quantities must be positive.")
            cart[product_id] = {"quantity": quantity}
        user_id = session["user"]["id"]
        db = get_db()
        try:
            order_id, total = db.create_order(customer_name, cart, user_id)
            return jsonify(order_id=order_id, total=total), 201
        finally:
            db.close()
    except (KeyError, ValueError, TypeError) as exc:
        return jsonify(error=str(exc)), 400


@app.delete("/api/orders/<int:order_id>")
@admin_required
def delete_order(order_id):
    db = get_db()
    try:
        db.delete_pending_order(order_id)
        return jsonify(ok=True)
    except ValueError as exc:
        return jsonify(error=str(exc)), 400
    finally:
        db.close()


@app.patch("/api/orders/<int:order_id>/status")
@login_required
def change_order_status(order_id):
    payload = request.get_json(silent=True) or {}
    status = str(payload.get("status", ""))
    user = session.get("user") or {}
    role = str(user.get("role", "")).lower()
    if status == "Preparing" and role not in ("staff", "admin", "manager"):
        return jsonify(error="Only a staff or admin account can accept an order."), 403
    if status == "Completed" and role not in ("staff", "admin", "manager"):
        return jsonify(error="Only a staff or admin account can complete an order."), 403
    db = get_db()
    try:
        db.update_order_status(order_id, status, user.get("id"))
        return jsonify(ok=True)
    except ValueError as exc:
        return jsonify(error=str(exc)), 400
    finally:
        db.close()



@app.get("/api/customers")
@admin_required
def customers():
    db = get_db()
    try:
        rows = db.conn.execute("SELECT id, full_name, username, email, phone, address, created_at FROM customers ORDER BY id DESC").fetchall()
        return jsonify([dict(r) for r in rows])
    finally:
        db.close()


@app.delete("/api/customers/<int:customer_id>")
@admin_required
def delete_customer(customer_id):
    db = get_db()
    try:
        row = db.conn.execute("SELECT username FROM customers WHERE id=?", (customer_id,)).fetchone()
        if not row:
            return jsonify(error="Customer not found."), 404
        user = db.conn.execute("SELECT id FROM users WHERE username=?", (row["username"],)).fetchone()
        if user:
            db.delete_user(user["id"])
        else:
            db.conn.execute("DELETE FROM customers WHERE id=?", (customer_id,))
            db.conn.commit()
        return jsonify(ok=True)
    finally:
        db.close()


@app.get("/api/accounts")
@admin_required
def accounts():
    db = get_db()
    try:
        rows = db.conn.execute("SELECT id, full_name, username, role FROM users ORDER BY CASE lower(role) WHEN 'admin' THEN 0 WHEN 'staff' THEN 1 ELSE 2 END, full_name").fetchall()
        return jsonify([dict(r) for r in rows])
    finally:
        db.close()


@app.delete("/api/accounts/<int:user_id>")
@admin_required
def delete_account(user_id):
    current = session.get("user", {})
    if int(current.get("id", -1)) == user_id:
        return jsonify(error="You cannot delete the account currently signed in."), 400
    db = get_db()
    try:
        row = db.conn.execute("SELECT id, role FROM users WHERE id=?", (user_id,)).fetchone()
        if not row:
            return jsonify(error="Account not found."), 404
        if row["role"].lower() == "admin":
            count = db.conn.execute("SELECT COUNT(*) FROM users WHERE lower(role)='admin'").fetchone()[0]
            if count <= 1:
                return jsonify(error="The last Admin account cannot be deleted."), 400
        db.delete_user(user_id)
        return jsonify(ok=True)
    finally:
        db.close()

@app.get("/api/reports")
@admin_required
def reports():
    start = request.args.get("start", "")
    end = request.args.get("end", "")
    try:
        date.fromisoformat(start)
        date.fromisoformat(end)
        if start > end:
            raise ValueError("Start date must be on or before end date.")
    except ValueError:
        return jsonify(error="Enter a valid date range."), 400
    db = get_db()
    try:
        rows = [dict(r) for r in db.sales_report(start, end)]
        return jsonify(rows=rows, total=sum(float(r["total_sales"] or 0) for r in rows),
                       order_count=sum(int(r["order_count"] or 0) for r in rows))
    finally:
        db.close()


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=int(os.environ.get("PORT", "5000")), debug=False)
