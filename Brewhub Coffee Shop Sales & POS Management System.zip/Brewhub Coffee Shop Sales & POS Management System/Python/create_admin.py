"""Secure one-time setup for the first BrewHub Admin account.
Run from the project root: python Python\create_admin.py
This does not expose Admin registration through the public website.
"""
from getpass import getpass
import sys
from pathlib import Path

PYTHON_DIR = Path(__file__).resolve().parent
if str(PYTHON_DIR) not in sys.path:
    sys.path.insert(0, str(PYTHON_DIR))
from database import Database


def main():
    db = Database()
    try:
        admins = db.conn.execute("SELECT COUNT(*) FROM users WHERE lower(role)='admin'").fetchone()[0]
        if admins:
            print("An Admin account already exists. No changes were made.")
            return
        full_name = input("Admin full name: ").strip()
        username = input("Admin username (at least 3 characters): ").strip()
        password = getpass("Admin password (at least 8 characters): ")
        confirm = getpass("Confirm password: ")
        if not full_name or len(username) < 3 or len(password) < 8:
            print("Setup cancelled: enter a name, username of at least 3 characters, and password of at least 8 characters.")
            return
        if password != confirm:
            print("Setup cancelled: passwords do not match.")
            return
        try:
            db.create_user(full_name, username, password, "Admin")
        except Exception as exc:
            print(f"Could not create Admin account: {exc}")
            return
        print("Admin account created successfully. Sign in through BrewHub.")
    finally:
        db.close()

if __name__ == "__main__":
    main()
