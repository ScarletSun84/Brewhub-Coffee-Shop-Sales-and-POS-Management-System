"""SQLite database layer for the BrewHub desktop application.
The database is stored beside this file as Python/brewhub.db.
"""
import sqlite3
import hashlib
from pathlib import Path
from datetime import datetime, date

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DB_NAME = str(Path(__file__).resolve().parent / "brewhub.db")

def hash_password(password: str) -> str:
    return hashlib.sha256(password.encode("utf-8")).hexdigest()


class Database:
    """Handles all SQLite database operations."""

    def __init__(self, db_name=DB_NAME):
        # One application connection to one SQLite database.
        # Foreign-key enforcement is enabled before any schema/data work.
        self.conn = sqlite3.connect(db_name, timeout=10)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA foreign_keys = ON")
        self.conn.execute("PRAGMA journal_mode = WAL")
        self.conn.execute("PRAGMA busy_timeout = 10000")
        self.create_tables()
        self.seed_data()
        self.repair_data_integrity()
        self.sync_customers_to_users()

    def create_tables(self):
        cur = self.conn.cursor()
        cur.executescript("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                full_name TEXT NOT NULL,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                role TEXT NOT NULL DEFAULT 'Staff'
            );

            CREATE TABLE IF NOT EXISTS customers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                full_name TEXT NOT NULL,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                email TEXT,
                phone TEXT,
                address TEXT,
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS products (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                category TEXT NOT NULL,
                price REAL NOT NULL,
                stock INTEGER NOT NULL DEFAULT 0,
                active INTEGER NOT NULL DEFAULT 1
            );

            CREATE TABLE IF NOT EXISTS orders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                customer_name TEXT NOT NULL,
                total REAL NOT NULL,
                created_at TEXT NOT NULL,
                user_id INTEGER,
                FOREIGN KEY(user_id) REFERENCES users(id)
            );

            CREATE TABLE IF NOT EXISTS order_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                order_id INTEGER NOT NULL,
                product_id INTEGER NOT NULL,
                quantity INTEGER NOT NULL,
                price REAL NOT NULL,
                subtotal REAL NOT NULL,
                FOREIGN KEY(order_id) REFERENCES orders(id),
                FOREIGN KEY(product_id) REFERENCES products(id)
            );

            CREATE TABLE IF NOT EXISTS inventory (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                product_id INTEGER UNIQUE NOT NULL,
                quantity INTEGER NOT NULL DEFAULT 0,
                reorder_level INTEGER NOT NULL DEFAULT 5,
                updated_at TEXT NOT NULL,
                FOREIGN KEY(product_id) REFERENCES products(id)
            );

            CREATE TABLE IF NOT EXISTS sales (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                order_id INTEGER UNIQUE NOT NULL,
                amount REAL NOT NULL,
                sold_at TEXT NOT NULL,
                FOREIGN KEY(order_id) REFERENCES orders(id)
            );
        """)
        # Add order status to databases created by older versions of BrewHub.
        order_columns = [row[1] for row in cur.execute("PRAGMA table_info(orders)").fetchall()]
        if "status" not in order_columns:
            cur.execute("ALTER TABLE orders ADD COLUMN status TEXT NOT NULL DEFAULT 'Pending'")
        # Helpful indexes for the POS workload.
        cur.execute("CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status)")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_orders_created_at ON orders(created_at)")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_order_items_order_id ON order_items(order_id)")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_order_items_product_id ON order_items(product_id)")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_sales_sold_at ON sales(sold_at)")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_customers_username ON customers(username)")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_users_role ON users(role)")
        self.conn.commit()

    def seed_data(self):
        cur = self.conn.cursor()

        if cur.execute("SELECT COUNT(*) FROM products").fetchone()[0] == 0:
            products = [
                ("Espresso", "Coffee", 90, 25),
                ("Americano", "Coffee", 110, 25),
                ("Cappuccino", "Coffee", 130, 20),
                ("Cafe Latte", "Coffee", 140, 20),
                ("Mocha", "Coffee", 150, 18),
                ("Caramel Macchiato", "Coffee", 160, 15),
                ("Iced Coffee", "Cold Drinks", 120, 25),
                ("Chocolate Frappe", "Frappe", 155, 15),
                ("Matcha Latte", "Non-Coffee", 145, 15),
                ("Croissant", "Pastry", 85, 20),
            ]
            cur.executemany(
                "INSERT INTO products(name, category, price, stock) VALUES (?, ?, ?, ?)",
                products,
            )

        products = cur.execute("SELECT id, stock FROM products").fetchall()
        for p in products:
            cur.execute(
                """INSERT OR IGNORE INTO inventory
                   (product_id, quantity, reorder_level, updated_at)
                   VALUES (?, ?, ?, ?)""",
                (p["id"], p["stock"], 5, datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
            )
        self.conn.commit()

    def repair_data_integrity(self):
        """Repair safe, non-destructive consistency issues in an existing database.

        The products table is the operational source of truth for current stock.
        The inventory table mirrors that quantity for inventory management. All
        application stock mutations update both records in one transaction.
        Existing orders and sales are preserved.
        """
        cur = self.conn.cursor()
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        # Ensure every active product has exactly one inventory row.
        products = cur.execute("SELECT id, stock FROM products").fetchall()
        for product in products:
            cur.execute(
                """INSERT OR IGNORE INTO inventory
                   (product_id, quantity, reorder_level, updated_at)
                   VALUES (?, ?, 5, ?)""",
                (product["id"], product["stock"], now),
            )
            # Repair a stale duplicate stock value without changing product stock.
            cur.execute(
                """UPDATE inventory
                   SET quantity=?, updated_at=?
                   WHERE product_id=? AND quantity <> ?""",
                (product["stock"], now, product["id"], product["stock"]),
            )

        # Remove orphan inventory rows left by older versions.
        cur.execute(
            """DELETE FROM inventory
               WHERE product_id NOT IN (SELECT id FROM products)"""
        )

        # Normalize any missing/invalid legacy order statuses.
        cur.execute(
            """UPDATE orders
               SET status='Pending'
               WHERE status IS NULL OR status NOT IN
                     ('Pending','Preparing','Completed')"""
        )

        # Sales must exist exactly once for completed orders.
        completed = cur.execute(
            "SELECT id, total, created_at FROM orders WHERE status='Completed'"
        ).fetchall()
        for order in completed:
            cur.execute(
                """INSERT OR IGNORE INTO sales(order_id, amount, sold_at)
                   VALUES (?, ?, ?)""",
                (order["id"], order["total"], order["created_at"]),
            )

        # Never leave sales records for non-completed orders.
        cur.execute(
            """DELETE FROM sales
               WHERE order_id IN
                 (SELECT id FROM orders WHERE status <> 'Completed')"""
        )

        self.conn.commit()

    def sync_customers_to_users(self):
        """Make previously-created customer accounts usable by the login system."""
        customers = self.conn.execute(
            "SELECT full_name, username, password FROM customers"
        ).fetchall()
        for customer in customers:
            exists = self.conn.execute(
                "SELECT 1 FROM users WHERE username=?", (customer["username"],)
            ).fetchone()
            if not exists:
                self.conn.execute(
                    "INSERT INTO users(full_name, username, password, role) VALUES (?, ?, ?, ?)",
                    (customer["full_name"], customer["username"], customer["password"], "Customer"),
                )
        self.conn.commit()

    def authenticate(self, username, password):
        return self.conn.execute(
            "SELECT * FROM users WHERE username=? AND password=?",
            (username, hash_password(password)),
        ).fetchone()

    def user_count(self):
        return self.conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]

    def create_user(self, full_name, username, password, role="Admin"):
        self.conn.execute(
            "INSERT INTO users(full_name, username, password, role) VALUES (?, ?, ?, ?)",
            (full_name.strip(), username.strip(), hash_password(password), role),
        )
        self.conn.commit()

    def create_customer(self, full_name, username, password, email="", phone="", address=""):
        """Create a customer in both the customer profile table and users table.

        Keeping a matching users record allows customer accounts to authenticate
        through the same login screen and appear in User Management.
        """
        full_name = full_name.strip()
        username = username.strip()
        password_hash = hash_password(password)
        created_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        if self.conn.execute("SELECT 1 FROM users WHERE username=?", (username,)).fetchone():
            raise sqlite3.IntegrityError("username already exists")
        if self.conn.execute("SELECT 1 FROM customers WHERE username=?", (username,)).fetchone():
            raise sqlite3.IntegrityError("customer username already exists")

        try:
            self.conn.execute(
                "INSERT INTO users(full_name, username, password, role) VALUES (?, ?, ?, ?)",
                (full_name, username, password_hash, "Customer"),
            )
            self.conn.execute(
                """INSERT INTO customers(full_name, username, password, email, phone, address, created_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (full_name, username, password_hash, email.strip(), phone.strip(), address.strip(), created_at),
            )
            self.conn.commit()
        except Exception:
            self.conn.rollback()
            raise

    def delete_user(self, user_id):
        """Delete a user account and its linked customer profile, if any."""
        row = self.conn.execute(
            "SELECT id, username, role FROM users WHERE id=?", (user_id,)
        ).fetchone()
        if not row:
            raise ValueError("User account not found.")

        try:
            # Keep historical orders valid. Their staff member becomes Unknown
            # instead of leaving a dangling foreign key.
            self.conn.execute(
                "UPDATE orders SET user_id=NULL WHERE user_id=?", (user_id,)
            )
            self.conn.execute(
                "DELETE FROM customers WHERE username=?", (row["username"],)
            )
            self.conn.execute("DELETE FROM users WHERE id=?", (user_id,))
            self.conn.commit()
        except Exception:
            self.conn.rollback()
            raise

    def add_product(self, name, category, price, stock):
        stock = int(stock)
        if stock < 0:
            raise ValueError("Stock quantity cannot be negative.")
        cur = self.conn.cursor()
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        try:
            cur.execute(
                "INSERT INTO products(name, category, price, stock) VALUES (?, ?, ?, ?)",
                (name.strip(), category.strip(), float(price), stock),
            )
            product_id = cur.lastrowid
            cur.execute(
                "INSERT INTO inventory(product_id, quantity, reorder_level, updated_at) VALUES (?, ?, ?, ?)",
                (product_id, stock, 5, now),
            )
            self.conn.commit()
        except Exception:
            self.conn.rollback()
            raise

    def update_product(self, product_id, name, category, price, stock):
        stock = int(stock)
        if stock < 0:
            raise ValueError("Stock quantity cannot be negative.")
        cur = self.conn.cursor()
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        try:
            cur.execute(
                "UPDATE products SET name=?, category=?, price=?, stock=? WHERE id=?",
                (name.strip(), category.strip(), float(price), stock, product_id),
            )
            if cur.rowcount != 1:
                raise ValueError("Product not found.")
            cur.execute(
                "UPDATE inventory SET quantity=?, updated_at=? WHERE product_id=?",
                (stock, now, product_id),
            )
            if cur.rowcount != 1:
                raise ValueError("Inventory record is missing for this product.")
            self.conn.commit()
        except Exception:
            self.conn.rollback()
            raise

    def delete_product(self, product_id):
        """Deactivate a product instead of physically deleting history-linked rows."""
        cur = self.conn.cursor()
        product = cur.execute(
            "SELECT id, active FROM products WHERE id=?", (product_id,)
        ).fetchone()
        if not product:
            raise ValueError("Product not found.")

        # Historical order_items reference product IDs. Soft deletion preserves
        # those records so past receipts/reports remain accurate.
        cur.execute("UPDATE products SET active=0 WHERE id=?", (product_id,))
        self.conn.commit()

    def products(self):
        return self.conn.execute(
            "SELECT * FROM products WHERE active=1 ORDER BY category, name"
        ).fetchall()

    def active_product_count(self):
        return self.conn.execute(
            "SELECT COUNT(*) FROM products WHERE active=1"
        ).fetchone()[0]

    def all_products(self):
        return self.conn.execute(
            "SELECT * FROM products ORDER BY id DESC"
        ).fetchall()

    def update_stock(self, product_id, quantity):
        """Set current stock in one atomic transaction.

        ``products.stock`` is the operational stock value used by the POS, while
        ``inventory.quantity`` mirrors it for inventory management. Both rows are
        updated together; invalid quantities and missing inventory records are
        rejected so the two tables cannot silently diverge.
        """
        quantity = int(quantity)
        if quantity < 0:
            raise ValueError("Stock quantity cannot be negative.")

        cur = self.conn.cursor()
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        try:
            product = cur.execute(
                "SELECT id FROM products WHERE id=?", (product_id,)
            ).fetchone()
            if not product:
                raise ValueError("Product not found.")

            cur.execute(
                "UPDATE products SET stock=? WHERE id=?", (quantity, product_id)
            )
            if cur.rowcount != 1:
                raise ValueError("Product stock could not be updated.")

            cur.execute(
                "UPDATE inventory SET quantity=?, updated_at=? WHERE product_id=?",
                (quantity, now, product_id),
            )
            if cur.rowcount != 1:
                raise ValueError("Inventory record is missing for this product.")

            self.conn.commit()
        except Exception:
            self.conn.rollback()
            raise

    def create_order(self, customer_name, cart, user_id):
        """Create an order atomically and reserve its stock.

        Prices are read from the database at placement time so a stale UI cart
        cannot overwrite the current product price.
        """
        if not cart:
            raise ValueError("The order cart is empty.")

        cur = self.conn.cursor()
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        try:
            # The POS user who enters a customer's name is not necessarily
            # the staff member who accepts/prepares the order. Assignment happens
            # only when a staff account starts the order.
            user_id = None

            validated_items = []
            total = 0.0

            for product_id, item in cart.items():
                quantity = int(item.get("quantity", 0))
                if quantity <= 0:
                    raise ValueError(f"Invalid quantity for {item.get('name', 'product')}.")

                product = cur.execute(
                    """SELECT id, name, price, stock
                       FROM products
                       WHERE id=? AND active=1""",
                    (product_id,),
                ).fetchone()

                if not product:
                    raise ValueError("One of the selected products is no longer available.")
                if product["stock"] < quantity:
                    raise ValueError(
                        f"Insufficient stock for {product['name']}. "
                        f"Available: {product['stock']}."
                    )

                price = float(product["price"])
                subtotal = price * quantity
                total += subtotal
                validated_items.append(
                    (product["id"], product["name"], quantity, price, subtotal)
                )

            cur.execute(
                """INSERT INTO orders
                   (customer_name,total,created_at,user_id,status)
                   VALUES(?,?,?,?,?)""",
                (customer_name.strip(), total, now, user_id, "Pending"),
            )
            order_id = cur.lastrowid

            for product_id, _name, quantity, price, subtotal in validated_items:
                cur.execute(
                    """INSERT INTO order_items
                       (order_id,product_id,quantity,price,subtotal)
                       VALUES(?,?,?,?,?)""",
                    (order_id, product_id, quantity, price, subtotal),
                )

                # Decrement both stock records conditionally. This prevents an
                # oversell and makes the stock reservation atomic with the order.
                cur.execute(
                    """UPDATE products
                       SET stock=stock-?
                       WHERE id=? AND active=1 AND stock>=?""",
                    (quantity, product_id, quantity),
                )
                if cur.rowcount != 1:
                    raise ValueError(
                        f"Insufficient stock for product ID {product_id}."
                    )

                cur.execute(
                    """UPDATE inventory
                       SET quantity=quantity-?, updated_at=?
                       WHERE product_id=? AND quantity>=?""",
                    (quantity, now, product_id, quantity),
                )
                if cur.rowcount != 1:
                    raise ValueError(
                        f"Inventory record is missing or insufficient for product ID {product_id}."
                    )

            self.conn.commit()
            return order_id, total

        except Exception:
            self.conn.rollback()
            raise

    def order_history(self):
        return self.conn.execute("""
            SELECT o.id, o.customer_name, o.total, o.created_at, o.status,
                   CASE WHEN o.status = 'Pending' THEN NULL ELSE u.full_name END AS staff
            FROM orders o
            LEFT JOIN users u ON o.user_id = u.id
            ORDER BY o.id DESC
        """).fetchall()

    def active_orders(self):
        return self.conn.execute("""
            SELECT o.id, o.customer_name, o.total, o.created_at, o.status,
                   CASE WHEN o.status = 'Pending' THEN NULL ELSE u.full_name END AS staff
            FROM orders o
            LEFT JOIN users u ON o.user_id = u.id
            WHERE o.status IN ('Pending', 'Preparing')
            ORDER BY o.id ASC
        """).fetchall()

    def delete_pending_order(self, order_id):
        """Delete a pending order and return its reserved quantities to stock."""
        cur = self.conn.cursor()
        order = cur.execute(
            "SELECT id, status FROM orders WHERE id=?", (order_id,)
        ).fetchone()
        if not order:
            raise ValueError("Order not found.")
        if order["status"] != "Pending":
            raise ValueError("Only pending orders can be deleted. Preparing or completed orders are preserved.")

        try:
            items = cur.execute(
                "SELECT product_id, quantity FROM order_items WHERE order_id=?",
                (order_id,),
            ).fetchall()
            now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            for item in items:
                cur.execute(
                    "UPDATE products SET stock=stock+? WHERE id=?",
                    (item["quantity"], item["product_id"]),
                )
                cur.execute(
                    "UPDATE inventory SET quantity=quantity+?, updated_at=? WHERE product_id=?",
                    (item["quantity"], now, item["product_id"]),
                )
            cur.execute("DELETE FROM order_items WHERE order_id=?", (order_id,))
            cur.execute("DELETE FROM sales WHERE order_id=?", (order_id,))
            cur.execute("DELETE FROM orders WHERE id=?", (order_id,))
            self.conn.commit()
        except Exception:
            self.conn.rollback()
            raise

    def update_order_status(self, order_id, status, accepted_by_user_id=None):
        allowed = {"Pending", "Preparing", "Completed"}
        if status not in allowed:
            raise ValueError("Invalid order status.")

        cur = self.conn.cursor()
        order = cur.execute(
            "SELECT id, total, status, created_at FROM orders WHERE id=?",
            (order_id,),
        ).fetchone()
        if not order:
            raise ValueError("Order not found.")

        current = order["status"]

        # Enforce a simple one-way POS queue:
        # Pending -> Preparing -> Completed.
        if current == "Completed":
            if status != "Completed":
                raise ValueError("A completed order cannot be moved back to the queue.")
            return
        if current == "Pending" and status == "Completed":
            raise ValueError("An order must be Preparing before it can be Completed.")
        if current == "Preparing" and status == "Pending":
            raise ValueError("A Preparing order cannot be moved back to Pending.")

        try:
            if status == "Completed" and current != "Completed":
                cur.execute(
                    """INSERT OR IGNORE INTO sales(order_id,amount,sold_at)
                       VALUES(?,?,?)""",
                    (order_id, order["total"], datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
                )

            if current == "Pending" and status == "Preparing":
                if accepted_by_user_id is None:
                    raise ValueError("A staff account is required to accept this order.")
                staff_user = cur.execute(
                    "SELECT id, role FROM users WHERE id=?", (accepted_by_user_id,)
                ).fetchone()
                if not staff_user or str(staff_user["role"]).lower() not in ("staff", "admin", "manager"):
                    raise ValueError("Only a staff or admin account can accept an order.")
                # Keep user_id attached to the customer who placed the order.
                # Staff authorization is checked above; do not overwrite ownership.
                cur.execute(
                    "UPDATE orders SET status=? WHERE id=?",
                    (status, order_id),
                )
            else:
                cur.execute(
                    "UPDATE orders SET status=? WHERE id=?", (status, order_id)
                )
            self.conn.commit()
        except Exception:
            self.conn.rollback()
            raise

    def delete_order(self, order_id):
        """Delete an accidental Pending/Preparing order and restore its stock."""
        cur = self.conn.cursor()
        order = cur.execute(
            "SELECT id, status FROM orders WHERE id=?", (order_id,)
        ).fetchone()
        if not order:
            raise ValueError("Order not found.")
        if order["status"] == "Completed":
            raise ValueError("Completed orders cannot be deleted.")
        if order["status"] not in ("Pending", "Preparing"):
            raise ValueError("Only Pending or Preparing orders can be deleted.")

        items = cur.execute(
            "SELECT product_id, quantity FROM order_items WHERE order_id=?",
            (order_id,),
        ).fetchall()
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        try:
            # Restore every product quantity that was reserved by the order.
            for item in items:
                product = cur.execute(
                    "SELECT stock FROM products WHERE id=?", (item["product_id"],)
                ).fetchone()
                if product:
                    new_stock = product["stock"] + item["quantity"]
                    cur.execute(
                        "UPDATE products SET stock=? WHERE id=?",
                        (new_stock, item["product_id"]),
                    )
                    cur.execute(
                        "UPDATE inventory SET quantity=?, updated_at=? WHERE product_id=?",
                        (new_stock, now, item["product_id"]),
                    )

            # Remove the sale and order details so the accidental order no longer
            # appears in sales reports or order history.
            cur.execute("DELETE FROM sales WHERE order_id=?", (order_id,))
            cur.execute("DELETE FROM order_items WHERE order_id=?", (order_id,))
            cur.execute("DELETE FROM orders WHERE id=?", (order_id,))
            if cur.rowcount == 0:
                raise ValueError("Order not found.")
            self.conn.commit()
        except Exception:
            self.conn.rollback()
            raise

    def order_items(self, order_id):
        return self.conn.execute("""
            SELECT COALESCE(p.name, 'Deleted Product') AS name,
                   oi.quantity, oi.price, oi.subtotal
            FROM order_items oi
            LEFT JOIN products p ON oi.product_id=p.id
            WHERE oi.order_id=?
        """, (order_id,)).fetchall()

    def dashboard_stats(self):
        today = date.today().isoformat()
        sales = self.conn.execute(
            "SELECT COALESCE(SUM(amount),0) FROM sales WHERE sold_at LIKE ?",
            (today + "%",),
        ).fetchone()[0]
        orders = self.conn.execute(
            "SELECT COUNT(*) FROM orders WHERE created_at LIKE ?",
            (today + "%",),
        ).fetchone()[0]
        low = self.conn.execute(
            "SELECT COUNT(*) FROM products WHERE stock <= 5 AND active=1"
        ).fetchone()[0]
        products = self.conn.execute(
            "SELECT COUNT(*) FROM products WHERE active=1"
        ).fetchone()[0]
        return sales, orders, low, products

    def sales_report(self, start_date, end_date):
        return self.conn.execute("""
            SELECT DATE(sold_at) AS sale_date,
                   COUNT(*) AS order_count,
                   SUM(amount) AS total_sales
            FROM sales
            WHERE DATE(sold_at) BETWEEN DATE(?) AND DATE(?)
            GROUP BY DATE(sold_at)
            ORDER BY sale_date DESC
        """, (start_date, end_date)).fetchall()

    def integrity_check(self):
        """Return SQLite integrity status for diagnostics/testing."""
        row = self.conn.execute("PRAGMA integrity_check").fetchone()
        return row[0] if row else "unknown"

    def close(self):
        self.conn.close()

